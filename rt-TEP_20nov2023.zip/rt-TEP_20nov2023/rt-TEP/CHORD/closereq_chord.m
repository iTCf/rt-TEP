function closereq_bamp(g,~)

button = questdlg({'You are about to close CHANNEL LAYOUT. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
%     setappdata(g,'open',0)
%     delete(g)
set(g,'Visible','off')
end

