function varargout = chord(varargin)
% chord MATLAB code for chord.fig
%      chord, by itself, creates a new chord or raises the existing
%      singleton*.
%
%      H = chord returns the handle to a new chord or the handle to
%      the existing singleton*.
%
%      chord('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in chord.M with the given input arguments.
%
%      chord('Property','Value',...) creates a new chord or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before chord_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to chord_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help chord

% Last Modified by GUIDE v2.5 15-Feb-2019 12:33:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @chord_OpeningFcn, ...
                   'gui_OutputFcn',  @chord_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before chord is made visible.
function chord_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to chord (see VARARGIN)

% Choose default command line output for chord
handles.output = hObject;
set(handles.axes_ch,'Visible','off')
set(handles.axes_chnew,'Visible','off')

if length(varargin)==1
    handles.chlocs=varargin{1};
    handles.chlocs_new=[];
    ch_list={handles.chlocs.labels}';
    set(handles.list_CH,'String',ch_list);
    if isfield(handles.chlocs,'newlabels')
        set(handles.list_Coord,'String',{handles.chlocs.newlabels}');
    else
        set(handles.list_Coord,'String',ch_list);
    end
    

    TypeEEG={handles.chlocs.type};
    I_EEG=find(cellfun(@(x) strcmp(x,'EEG'),TypeEEG));
    cla(handles.axes_ch);
    if ~isempty(I_EEG)
        axes(handles.axes_ch);
        topoplot(zeros(length(I_EG),1),handles.chlocs(I_EEG),'maplimits',[-2 2],'style','map','electrodes','ptslabels','conv','off');%%%%%SCSCSCSCSC
             set(gcf,'Color',[0.94 0.94 0.94])

    end
end

ch_tab=cell(1,4);
set(handles.uitable1,'Data',ch_tab);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes chord wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = chord_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in list_CH.
function list_CH_Callback(hObject, eventdata, handles)
I=get(handles.list_CH,'Value');
set(handles.list_Coord,'Value',I)

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function list_CH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to list_CH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in list_Coord.
function list_Coord_Callback(hObject, eventdata, handles)
if isfield(handles,'chlocs')
I=get(handles.list_CH,'Value');
if isfield(handles.chlocs,'type') && ~strcmp(handles.chlocs(I).type,'EEG')
    set(handles.list_Coord,'Value',I)
end

Icoord=get(handles.list_Coord,'Value');
if isfield(handles.chlocs,'type') && strcmp(handles.chlocs(I).type,'EEG') && ~strcmp(handles.chlocs(Icoord).type,'EEG')
    set(handles.list_Coord,'Value',I)
end
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function list_Coord_CreateFcn(hObject, eventdata, handles)
% hObject    handle to list_Coord (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Default_Butt.
function Default_Butt_Callback(hObject, eventdata, handles)
button = questdlg({'Previously selected single channels will be deleted. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
    if isfield(handles,'chlocs')
        ch_list1={handles.chlocs.labels}';
        ch_list2={handles.chlocs.newlabels}';
        col3={handles.chlocs.type}';
        col4=repmat({false},[1 size(ch_list1,1)])';
        ch_tab=[ch_list1, ch_list2, col3,col4];
        set(handles.uitable1,'Data',ch_tab);
        handles.chlocs_new=handles.chlocs;
        
        I_EEG=find(cellfun(@(x) strcmp(x,'EEG'),ch_tab(:,3)));
        cla(handles.axes_chnew);
        if ~isempty(I_EEG)
            axes(handles.axes_chnew);
            topoplot(zeros(length(I_EEG),1),handles.chlocs_new(I_EEG),'maplimits',[-2 2],'style','map','electrodes','ptslabels','emarker2',{1:length(I_EEG),'o','r',7,1},'conv','off');%%%SCSCSCSCSC
                 set(gcf,'Color',[0.94 0.94 0.94])

        end
    end
end

guidata(hObject, handles);


% --- Executes on button press in Select_CH.
function Select_CH_Callback(hObject, eventdata, handles)
if isfield(handles,'chlocs')
ch_list=get(handles.list_CH,'String');
ch_sel=get(handles.list_CH,'Value');
coord_list=get(handles.list_Coord,'String');
coord_sel=get(handles.list_Coord,'Value');

ch_tab=get(handles.uitable1,'Data');
check1=find(strcmp(ch_tab(:,1),ch_list{ch_sel}));
check2=find(strcmp(ch_tab(:,2),coord_list{coord_sel}));

if ~isempty(check1)
    errordlg('Channel already selected','Channel Error');
    return
elseif ~isempty(check2)
    errordlg('Coordinate already selected','Channel Error');
    return
end

I_tab=size(ch_tab,1);
if ~isempty(ch_tab{I_tab,1})
    I_tab=I_tab+1;
end
ch_tab{I_tab,1}=ch_list{ch_sel};
ch_tab{I_tab,2}=coord_list{coord_sel};
ch_tab{I_tab,4}=false;

if isempty(handles.chlocs_new)
    handles.chlocs_new=handles.chlocs(coord_sel);
else
    handles.chlocs_new(length(handles.chlocs_new)+1)=handles.chlocs(coord_sel);
end
handles.chlocs_new(length(handles.chlocs_new)).labels=handles.chlocs(ch_sel).labels;
if ~isfield(handles.chlocs_new(length(handles.chlocs_new)),'type')
    handles.chlocs_new(length(handles.chlocs_new)).type='EEG';
end
ch_tab{I_tab,3}=handles.chlocs(ch_sel).type;

set(handles.uitable1,'Data',ch_tab);

I_EEG=find(cellfun(@(x) strcmp(x,'EEG'),ch_tab(:,3)));
cla(handles.axes_chnew);
if ~isempty(I_EEG)
    axes(handles.axes_chnew);
     topoplot(zeros(length(I_EEG),1),[handles.chlocs_new(I_EEG)],'maplimits',[-2 2],'style','map','electrodes','ptslabels','emarker2',{[1:length(I_EEG)],'o','r',7,1},'conv','off');%%%SCSCSCSCSC
         set(gcf,'Color',[0.94 0.94 0.94])

%     topoplot(zeros(length(I_EEG)+1,1),[handles.chlocs_new(I_EEG) handles.centroid],'maplimits',[-2 2],'electrodes','ptslabels','emarker2',{[1:length(I_EEG)+1],'o','r',7,1},'conv','off');%%%SCSCSCSCSC
end
end
guidata(hObject, handles);


% --- Executes on button press in Up_Button.
function Up_Button_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
I_tmp=cellfun(@(x) find(x==1),ch_tab(:,4),'UniformOutput',false);
I_tmp=cellfun(@(x) ~isempty(x),I_tmp, 'UniformOutput', false);
I_up=find(cell2mat(I_tmp));
for kk=1:length(I_up)
    if I_up(kk)~=1
        tmp1=ch_tab(I_up(kk),:);
        tmp2=ch_tab(I_up(kk)-1,:);
        ch_tab(I_up(kk),:)=tmp2;
        ch_tab(I_up(kk)-1,:)=tmp1;
        clear tmp*
        
        tmp1=handles.chlocs_new(I_up(kk));
        tmp2=handles.chlocs_new(I_up(kk)-1);
        handles.chlocs_new(I_up(kk))=tmp2;
        handles.chlocs_new(I_up(kk)-1)=tmp1;
    end
    set(handles.uitable1,'Data',ch_tab);
end
guidata(hObject, handles);

% --- Executes on button press in Down_Button.
function Down_Button_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
I_tmp=cellfun(@(x) find(x==1),ch_tab(:,4),'UniformOutput',false);
I_tmp=cellfun(@(x) ~isempty(x),I_tmp, 'UniformOutput', false);
I_dw=find(cell2mat(I_tmp));
for kk=length(I_dw):-1:1
    if I_dw(kk)~=size(ch_tab,1)
        tmp1=ch_tab(I_dw(kk),:);
        tmp2=ch_tab(I_dw(kk)+1,:);
        ch_tab(I_dw(kk),:)=tmp2;
        ch_tab(I_dw(kk)+1,:)=tmp1;
        clear tmp*
        
        tmp1=handles.chlocs_new(I_dw(kk));
        tmp2=handles.chlocs_new(I_dw(kk)+1);
        handles.chlocs_new(I_dw(kk))=tmp2;
        handles.chlocs_new(I_dw(kk)+1)=tmp1;
    end
    set(handles.uitable1,'Data',ch_tab);
end
guidata(hObject, handles);


% --- Executes on button press in Reverse_Button.
function Reverse_Button_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
if ~isempty(cell2mat(ch_tab))
I_rev=size(ch_tab,1):-1:1;
ch_tab=ch_tab(I_rev,:);
set(handles.uitable1,'Data',ch_tab);
handles.chlocs_new=handles.chlocs_new(I_rev);
end
guidata(hObject, handles);

% --- Executes on button press in Delete_CH.
function Delete_CH_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
I_tmp=cellfun(@(x) find(x==1),ch_tab(:,4),'UniformOutput',false);
I_tmp=cellfun(@(x) ~isempty(x),I_tmp, 'UniformOutput', false);
I_del=find(cell2mat(I_tmp));
if ~isempty(I_del)
    if size(ch_tab,1)~=1
        ch_tab(I_del,:)=[];
        handles.chlocs_new(I_del)=[];
        ocio=0;
    else
        ch_tab=cell(1,4);
        handles.chlocs_new=[];
        ocio=1;
    end
    set(handles.uitable1,'Data',ch_tab);
    I_EEG=find(cellfun(@(x) strcmp(x,'EEG'),ch_tab(:,3)));
    cla(handles.axes_chnew);
    if ~isempty(I_EEG)
        axes(handles.axes_chnew);
        topoplot(zeros(length(I_EEG),1),handles.chlocs_new(I_EEG),'maplimits',[-2 2],'style','map','electrodes','ptslabels','emarker2',{[1:length(I_EEG)],'o','r',7,1},'conv','off');%SCSCSCSCSCSC
             set(gcf,'Color',[0.94 0.94 0.94])

    end
end
guidata(hObject, handles);


% --- Executes on button press in Delete_ALL.
function Delete_ALL_Callback(hObject, eventdata, handles)
ch_tab=cell(1,4);
set(handles.uitable1,'Data',ch_tab);
cla(handles.axes_chnew);
handles.chlocs_new=[];
guidata(hObject, handles);


% --- Executes on button press in Load_File.
function Load_File_Callback(hObject, eventdata, handles)
[FileName,PathName]=uigetfile(strcat(cd,'\*.mat'));% select .mat file
if isempty(FileName) || unique(FileName==false)
    return
end
load(strcat(PathName,FileName),'chlocs');
handles.chlocs=chlocs;
if ~isfield(handles,'chlocs_new')
    handles.chlocs_new=[];
end
ch_list={handles.chlocs.labels}';
set(handles.list_CH,'String',ch_list);
if isfield(handles.chlocs,'newlabels')
    set(handles.list_Coord,'String',{handles.chlocs.newlabels}');
else
    set(handles.list_Coord,'String',ch_list);
end

TypeEEG={handles.chlocs.type};
I_EEG=find(cellfun(@(x) strcmp(x,'EEG'),TypeEEG));
cla(handles.axes_ch);
if ~isempty(I_EEG)
    axes(handles.axes_ch);
    topoplot(zeros(length(I_EEG),1),handles.chlocs(I_EEG),'maplimits',[-2 2],'style','map','electrodes','ptslabels','conv','off')%SCSCSCSCSC
    set(gcf,'Color',[0.94 0.94 0.94])
end

set(handles.list_CH,'Value',1);
set(handles.list_Coord,'Value',1);
guidata(hObject, handles);


% --- Executes on button press in Save_list.
function Save_list_Callback(hObject, eventdata, handles)
chlocs=handles.chlocs_new;
[file,path] = uiputfile('*.mat','Save electrodes location information');
if file
    save(strcat(path,file(1:strfind(file,'.')-1),'.mat'),'chlocs')
    msgbox('Data have been saved. In order to proceed, close CHANNEL LAYOUT')
end
guidata(hObject, handles);


% --- Executes on button press in pushTOP.
function pushTOP_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
I_tmp=cellfun(@(x) find(x==1),ch_tab(:,4),'UniformOutput',false);
I_tmp=cellfun(@(x) ~isempty(x),I_tmp, 'UniformOutput', false);
I_up=find(cell2mat(I_tmp));
if ~isempty(I_up)
    I_fissi=setdiff(1:size(ch_tab),I_up);
    ch_tab_new=[ch_tab(I_up,:); ch_tab(I_fissi,:)];
    set(handles.uitable1,'Data',ch_tab_new);
    handles.chlocs_new=[handles.chlocs_new(I_up), handles.chlocs_new(I_fissi)];
end

guidata(hObject, handles);


% --- Executes on button press in pushBottom.
function pushBottom_Callback(hObject, eventdata, handles)
ch_tab=get(handles.uitable1,'Data');
I_tmp=cellfun(@(x) find(x==1),ch_tab(:,4),'UniformOutput',false);
I_tmp=cellfun(@(x) ~isempty(x),I_tmp, 'UniformOutput', false);
I_bottom=find(cell2mat(I_tmp));
if ~isempty(I_bottom)
    I_fissi=setdiff(1:size(ch_tab),I_bottom);
    ch_tab_new=[ch_tab(I_fissi,:); ch_tab(I_bottom,:)];
    set(handles.uitable1,'Data',ch_tab_new);
    handles.chlocs_new=[handles.chlocs_new(I_fissi), handles.chlocs_new(I_bottom)];
end

guidata(hObject, handles);


% --- Executes on button press in pushHVEOG.
function pushHVEOG_Callback(hObject, eventdata, handles)
if ~isfield(handles,'chlocs')
    msgbox('Load a .mat file with electrode location information first!','Error')
else

ch_tab=get(handles.uitable1,'Data');
checkV=find(strcmp(ch_tab(:,1),'VEOG'));
checkH=find(strcmp(ch_tab(:,1),'HEOG'));

if ~isempty(checkV) && ~isempty(checkH)
    errordlg('Channels already selected','Channel Error');
    return
end

I_tab=size(ch_tab,1);
if ~isempty(ch_tab{I_tab,1})
    I_tab=I_tab+1;
end

nomicampi=fieldnames(handles.chlocs);
tmp_ins=[];
for jj=1:length(nomicampi)
    tmp_ins.(nomicampi{jj})=[];
end
tmp_ins.type='EOG';
clear nomicampi
    
if isempty(checkV)
    ch_tab{I_tab,1}='VEOG';
    ch_tab{I_tab,2}='';
    ch_tab{I_tab,4}=false;
    ch_tab{I_tab,3}='EOG';
    I_tab=I_tab+1;

    tmp_ins.labels='VEOG';
    tmp_ins.newlabels='VEOG';
    if isempty(handles.chlocs_new)
        handles.chlocs_new=tmp_ins;
    else
        handles.chlocs_new(length(handles.chlocs_new)+1)=tmp_ins;
    end
    
end
if isempty(checkH)
    ch_tab{I_tab,1}='HEOG';
    ch_tab{I_tab,2}='';
    ch_tab{I_tab,4}=false;
    ch_tab{I_tab,3}='EOG';
    
    tmp_ins.labels='HEOG';
    tmp_ins.newlabels='HEOG';
    if isempty(handles.chlocs_new)
        handles.chlocs_new=tmp_ins;
    else
        handles.chlocs_new(length(handles.chlocs_new)+1)=tmp_ins;
    end
    
end
set(handles.uitable1,'Data',ch_tab);
end
guidata(hObject, handles);


function editName_Callback(hObject, eventdata, handles)
% hObject    handle to editName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editName as text
%        str2double(get(hObject,'String')) returns contents of editName as a double


% --- Executes during object creation, after setting all properties.
function editName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listType.
function listType_Callback(hObject, eventdata, handles)
% hObject    handle to listType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listType


% --- Executes during object creation, after setting all properties.
function listType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushAdd_Ext.
function pushAdd_Ext_Callback(hObject, eventdata, handles)
if ~isfield(handles,'chlocs')
    msgbox('Load a .mat file with electrode location information first!','Error')
else
ch_ext{1,1}=get(handles.editName,'String');
if isempty(ch_ext{1,1})
    return
end
ch_tab=get(handles.uitable1,'Data');
check_ext=find(strcmp(ch_tab(:,1),ch_ext{1,1}));
if ~isempty(check_ext)
    errordlg('Channels already selected','Channel Error');
    return
end
ch_ext{1,2}='';
ch_ext{1,4}=false;
tmp=get(handles.listType,'String');
tmp2=get(handles.listType,'Value');
if tmp2>1
    ch_ext{1,3}='other';
else ch_ext{1,3}=tmp{tmp2};
end

I_tab=size(ch_tab,1);
if ~isempty(ch_tab{I_tab,1})
    I_tab=I_tab+1;
end
ch_tab(I_tab,:)=ch_ext;
set(handles.uitable1,'Data',ch_tab);
set(handles.editName,'String','')

nomicampi=fieldnames(handles.chlocs);
tmp_ins=[];
for jj=1:length(nomicampi)
    tmp_ins.(nomicampi{jj})=[];
end
tmp_ins.type=ch_ext{1,3};
clear nomicampi

tmp_ins.labels=ch_ext{1,1};
tmp_ins.newlabels=ch_ext{1,1};
if isempty(handles.chlocs_new)
    handles.chlocs_new=tmp_ins;
else
    handles.chlocs_new(length(handles.chlocs_new)+1)=tmp_ins;
end
end
guidata(hObject, handles);


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);
