function [concheck,con]=check_connection(handles)

concheck=1;

con = pnet('tcpconnect', handles.chord.ip, 51244);
stat = pnet(con,'status');
if stat <=0
    concheck=0;
end

