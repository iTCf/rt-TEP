function [dataavgtoplot,nTrials,nTrials_good]=RdDydata(handles,datarawtoplot,dataavgtoplot,ySeparation)

[concheck,con]=check_connection(handles);
% ySeparation=300;
if ~concheck
    msgbox('Connection cannot be established!','Error','error');
    cloh=close(h);
    return
    %uscire!!!
end
set(handles.axes_raw,'XLim',[min(handles.input.timesraw) max(handles.input.timesraw)],'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom
set(handles.axes_raw,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'XLim',handles.spm,'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom


handles.zoom_obj = zoom(handles.figure1);
handles.dcm_obj=datacursormode(handles.figure1);
set(handles.dcm_obj,'DisplayStyle','window')
set(handles.dcm_obj,'UpdateFcn',{@mydata_cursor,handles})


header_size = 24;
tryheader=[];
tic
while isempty(tryheader) && toc<5
    tryheader = pnet(con,'read',header_size,'byte','network','view','noblock'); % check for existing data in socket buffer
end

lastBlock=-1;
% nTrials=0;
% nTrials_good=0;
nTrials_good=getappdata(handles.pushbutton_common,'trialsgood');
nTrials=getappdata(handles.pushbutton_common,'trials');
start_trial=0;
while ~isempty(tryheader) && strcmp(get(handles.pushbutton_start,'String'),'STOP')
    cont1=0;%counter for updating rate of raw data
    cont2=0;%counter for updating avg data
    while cont1<handles.props.srate/handles.datahdr.points && strcmp(get(handles.pushbutton_start,'String'),'STOP') % plot raw data every s
        hdr = ReadHeader(con);
        switch hdr.type
            case 1
                props = ReadStartMessage(con, hdr);
                lastBlock = -1;% Reset block counter to check overflows
            case 4       % 32Bit Data block
                % Read data and markers from message
                mrkpos=[];
                tmp=[];
                [datahdr, data, markers] = ReadDataMessage(con, hdr, props);
                cont1=cont1+1;
                
                % check tcpip buffer overflow
                if lastBlock~=-1 && lastBlock~=datahdr.block-1
                    handles.overflow=handles.overflow+1;
                    handles.overflow
                end
                lastBlock=datahdr.block;
                EEGData = double(reshape(data, handles.props.channelCount, datahdr.points)); %provides a matrix (props.channelCount)X time samples
                
                %Check presence of stimulus
                %ci deve essere max 1 trigger su cui fare la media per pacchetto
                %                  markers=markers(1,1);
                %                  assignin('base','markers',markers)
                %=markers(1,1);
                %                  if ~cont2%SCSCSC
                if ~isempty(markers(1,1).description) && ~cont2
                    
                    tmp=find(cellfun(@(x) strcmp(x,handles.markername),{markers.description}));
                end
                if datahdr.markerCount>0 && ~isempty(tmp) && ~cont2
                    start_trial=1; %I must startin counting handles.displayparam.avg(2)/1000*handles.props.srate data packets to the right of the stimulus
                    mrkpos=markers(tmp).position+1;%Sample within the packet containing the stimulus
                end
                %                  end
                if start_trial
                    cont2=cont2+1;
                end
                %Process RAW data
                datarawtoplot(1:end-2,1:datahdr.points)=EEGData(handles.props.EEG,:)*handles.props.resolutionEEG;
                if length(handles.EOGchannels)==1
                    switch handles.EOGchannels
                        case 0
                            datarawtoplot(end-1,1:datahdr.points)=0;
                        otherwise
                            datarawtoplot(end-1,1:datahdr.points)=EEGData(handles.EOGchannels,:)*handles.props.resolutions(handles.EOGchannels);
                    end
                else datarawtoplot(end-1,1:datahdr.points)=(EEGData(handles.EOGchannels(2),:)-EEGData(handles.EOGchannels(1),:))*handles.props.resolutions(handles.EOGchannels(1));
                end
                datarawtoplot(end,1:datahdr.points)=0;
                if mrkpos
                    datarawtoplot(end,mrkpos)=100;
                end
                datarawtoplot=circshift(datarawtoplot,[0,-double(datahdr.points)]);
                
                % a full trial has been recorded
                if start_trial==1 && cont2>length(find(handles.input.timesavg>0))/datahdr.points%cont2 && (lastBlock-cont2)>handles.displayparam.avg(2)/1000*handles.props.srate/datahdr.points % find(datarawtoplot(end,:),1,'last')-abs(handles.displayparam.avg(1))/1000*handles.props.srate>0 && find(datarawtoplot(end,:),1,'last')+handles.displayparam.avg(2)/1000*handles.props.srate<size(datarawtoplot,2)%
                    nTrials=getappdata(handles.pushbutton_common,'trials')+1;
                    setappdata(handles.pushbutton_common,'trials',nTrials);
                    dataavgtmp=datarawtoplot(1:end-1,find(datarawtoplot(end,:),1,'last')-length(find(handles.input.timesavg<0)):find(datarawtoplot(end,:),1,'last')+length(find(handles.input.timesavg>0)));
                    dataavgtmp=dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-floor(0.01*handles.props.srate)),2),[1,size(dataavgtmp,2)]);
                    
                    setappdata(handles.pushbutton_common,'datacomst',dataavgtmp)
                    
                    if nTrials==1
                        dataavgtoplot=zeros(size(dataavgtmp));
                    else
                        dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
                    end
                    %                     dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
                    
                    %check whether EOG artifact rejection is on and the trial is good
                    switch get(handles.togglebutton_ampthresh,'Value')
                        case 1
                            if max(abs(dataavgtmp(end,:)))<abs(str2double(get(handles.edit_thresh,'String')))
                                dataavgtoplot=dataavgtoplot+dataavgtmp;
                                %                                 dataavgtoplot=dataavgtoplot+(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)]));
                                nTrials_good=getappdata(handles.pushbutton_common,'trialsgood')+1;
                                setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                            end
                        case 0
                            dataavgtoplot=dataavgtoplot+dataavgtmp;
                            %                             dataavgtoplot=dataavgtoplot+(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)]));
                            nTrials_good=getappdata(handles.pushbutton_common,'trialsgood')+1;
                            setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                    end
                    
                    setappdata(handles.pushbutton_common,'datacom',dataavgtoplot)
                    %                     setappdata(handles.pushbutton_common,'trialsgood',nTrials_good)
                    %                     setappdata(handles.pushbutton_common,'trials',nTrials)
                    
                    %                     %check whether SINGLE PULSE mode is on
                    %                     if get(handles.togglebutton_singlepulse,'Value')
                    %                         setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
                    % %                         setappdata(handles.pushbutton_common,'dataspm',(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)])))
                    %                         update_singlepulse(handles,1)
                    % %                         set(handles.uipanel_singlepulse,'Visible','on')
                    % %                         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingSINGLE'))
                    % %                         set(handles.uipanel_axesbfly,'Visible','off')
                    % %                         set(handles.uipanel_axesavg,'Visible','off')
                    % %                         set(handles.uipanel_axesraw,'Visible','off')
                    %                     end
                    
                    %update AVG display
                    if getappdata(handles.pushbutton_common,'trialsgood')
                        update_avg(handles)
                        
                    end
                    set(handles.text_trials,'String',strcat(num2str(getappdata(handles.pushbutton_common,'trialsgood')),'/',num2str(getappdata(handles.pushbutton_common,'trials'))));
                    
                 
                    start_trial=0;
                    cont2=0;
                end
            case 3       % Stop message
                disp('Stop');
%                 data = pnet(con, 'read', hdr.size - header_size);
                pnet('closeall');
            otherwise    % ignore all unknown types, but read the package from buffer
                data = pnet(con, 'read', hdr.size - header_size);
                %                 pnet('closeall');
        end
        if strcmp(get(handles.pushbutton_start,'String'),'STOP') % plotta i dati raw ogni secondo
            tryheader=[];
            while isempty(tryheader) && strcmp(get(handles.pushbutton_start,'String'),'STOP')
                tryheader = pnet(con, 'read', header_size, 'byte', 'network', 'view', 'noblock');
            end
        end
    end
    
    setappdata(handles.pushbutton_common,'dataraw',datarawtoplot);
    
    update_raw(handles)
    
    cont1=0;%counter for updating raw data
end
