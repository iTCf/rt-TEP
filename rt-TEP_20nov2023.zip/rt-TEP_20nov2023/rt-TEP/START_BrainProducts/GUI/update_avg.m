function update_avg(handles)


props=getappdata(handles.slider_raw,'props');
input=getappdata(handles.slider_raw,'input');
Hfilters=getappdata(handles.togglebutton_pass,'filters');
nTrials_good=getappdata(handles.pushbutton_common,'trialsgood');

datatmp=getappdata(handles.pushbutton_common,'datacom');
datatmpst=getappdata(handles.pushbutton_common,'datacomst');

% if isempty(datatmp)
%     datatmp=zeros(props.nEEG+1,length(input.timesavg));
% end

%check whether TMS artifact rejection is required
if get(handles.togglebutton_art,'Value')==1
    datatmp(:,find(input.timesavg==0)+round(str2double(get(handles.edit_tmin,'String'))/1000*props.srate):find(input.timesavg==0)+round(str2double(get(handles.edit_tmax,'String'))/1000*props.srate))=repmat(datatmp(:,find(input.timesavg==0)+round(str2double(get(handles.edit_tmin,'String'))/1000*props.srate)-1),[1,round((str2double(get(handles.edit_tmax,'String'))-str2double(get(handles.edit_tmin,'String')))/1000*props.srate)+1]);
    datatmpst(:,find(input.timesavg==0)+round(str2double(get(handles.edit_tmin,'String'))/1000*props.srate):find(input.timesavg==0)+round(str2double(get(handles.edit_tmax,'String'))/1000*props.srate))=repmat(datatmpst(:,find(input.timesavg==0)+round(str2double(get(handles.edit_tmin,'String'))/1000*props.srate)-1),[1,round((str2double(get(handles.edit_tmax,'String'))-str2double(get(handles.edit_tmin,'String')))/1000*props.srate)+1]);
end

%check whether filtering is required
switch get(handles.togglebutton_pass,'Value')
    case 1
        switch get(handles.togglebutton_stop,'Value')
            case 1
                datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
                datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
                datatmpst=filtfilt(Hfilters.Bl,Hfilters.Al,datatmpst')';
                datatmpst=filtfilt(Hfilters.Bn,Hfilters.An,datatmpst')';

            case 0
                datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
                datatmpst=filtfilt(Hfilters.Bl,Hfilters.Al,datatmpst')';
        end
    case 0
        switch get(handles.togglebutton_stop,'Value')
            case 1
                datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
                datatmpst=filtfilt(Hfilters.Bn,Hfilters.An,datatmpst')';
        end
end

%check whether AVG data have to be displayed in AVG or COM ref
if strcmp(get(handles.pushbutton_common,'String'),'COM ref')
    tmp=strcmp(get([props.channelNamesNew{1:end-2,3}],'Visible'),'on');
    datatmp(1:end-1,:)=datatmp(1:end-1,:)-repmat(mean(datatmp(tmp,:),1),[size(datatmp,1)-1,1]);
    tmp=strcmp(get([props.channelNamesNew{1:end-2,4}],'Visible'),'on');
    datatmpst(1:end-1,:)=datatmpst(1:end-1,:)-repmat(mean(datatmpst(tmp,:),1),[size(datatmpst,1)-1,1]);

end

set([props.channelNamesNew{1:end-1,3}],{'YData'},num2cell(datatmp*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingAVG')))/nTrials_good+input.deltaavg,2));%plot avg data
drawnow
% set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(datatmp(1:end-1,:)*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')))/nTrials_good,2));%plot bfly data
set([props.channelNamesNew{1:end-1,4}],{'YData'},num2cell(datatmpst*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')))+input.deltaavg,2));%plot sttopo data
drawnow

