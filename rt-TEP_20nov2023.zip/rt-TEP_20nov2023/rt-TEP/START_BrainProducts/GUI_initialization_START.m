function [outval]=GUI_initialization_START(handles)

cloh=0;
outval=0;
props_out=[];

h=waitbar(0,'Starting ...');

[concheck,con]=check_connection(handles);

if ~concheck
    msgbox('Connection cannot be established!','Error','error');
    cloh=close(h);
    return
    %uscire!!!
end


%read header message
header_size = 24;
tryheader=[];
tic
while isempty(tryheader) && toc<5
    tryheader = pnet(con,'read',header_size,'byte','network','view','noblock'); % check for existing data in socket buffer
end
if ~isempty(tryheader)
    cexit=1;
    waitbar(1/2,h)
    while cexit==1
        hdr = ReadHeader(con);
        switch hdr.type
            case 1
                props = ReadStartMessage(con, hdr);
                % Read and display recording parameters
                props.srate=1/(props.samplingInterval*(10^(-6)));
                %                 set(handles.text_sr,'String', num2str(props.srate)) % props.samplingInterval is expressed in microseconds
                props.EEG=find(cellfun(@(x) strcmp(x,'EEG'),{handles.chord.chlocs.type}));
                %                 if length(unique(props.resolutions))==1
                %                     set(handles.text_ampres,'String', num2str(props.resolutions(1)))
                %                 else
                %                     set(handles.text_ampres,'String', 'var.')
                %                 end
                if length(unique(props.resolutions(props.EEG)))==1
                    props.resolutionEEG=props.resolutions(props.EEG(1));
                else
                    msgbox('EEG channels have different resolutions!','Error','error');
                    cloh=close(h);
                    pnet('closeall');
                    msgbox('Connection has been closed!','Error','error');
                    return
                end
                props.nEEG=length(props.EEG);
                props.nEOG=length(find(cellfun(@(x) strcmp(x,'EOG'),{handles.chord.chlocs.type})));
                %                 set(handles.text_eegch,'String',num2str(props.nEEG))
                %                 set(handles.text_eogch,'String',num2str(props.nEOG))
                %                 set(handles.text_addch,'String',num2str(length(find(cellfun(@(x) strcmp(x,'other'),{handles.chord.chlocs.type})))))
                %check correspondence with input montage
                if props.channelCount~=size(handles.chord.chlocs,2)
                    msgbox('the number of received channels does not match input montage!','Error','error');
                    cloh=close(h);
                    pnet('closeall');
                    msgbox('Connection has been closed!','Error','error');
                    return
                    % uscire!!!!
                end
                if ~isequal(props.channelNames,{handles.chord.chlocs.labels})
                    msgbox('the labels of received channels do not match input montage!','Error','error');
                    cloh=close(h);
                    pnet('closeall');
                    msgbox('Connection has been closed!','Error','error');
                    return
                    % uscire!!!!
                end
                
                outval=1;
                waitbar(1,h);
            case 4       % 32Bit Data block
                % Read data and markers from message
                cexit=0;
                [datahdr, ~, ~] = ReadDataMessage(con, hdr, props);
                %         case 3       % Stop message
                %             data = pnet(con, 'read', hdr.size - header_size);
                %             stop_test=0;
            otherwise    % ignore all unknown types, but read the package from buffer
                data = pnet(con, 'read', hdr.size - header_size);%SCSCSCSCSC
                %                 cexit=0;
                %                 close(h)
                %                 msgbox('Unknown data type!','Error','error');
        end
        tryheader = pnet(con,'read',header_size,'byte','network','view','noblock'); % check for existing data in socket buffer
    end
else
    cloh=close(h);
    msgbox('Empty data buffer!','Error','error');
    pnet('closeall');
    msgbox('Connection has been closed!','Error','error');
    return
    % uscire!!!
end
props_out=props;
cloh=close(h);
% set(handles.panelacq,'Visible','on')
pnet('closeall');



