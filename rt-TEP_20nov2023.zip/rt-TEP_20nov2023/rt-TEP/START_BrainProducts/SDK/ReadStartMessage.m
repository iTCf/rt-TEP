% Read the start message
function props = ReadStartMessage(con, hdr)
    % con    tcpip connection object    
    % hdr    message header
    % props  returned eeg properties

    % define a struct for the EEG properties
    props = struct('channelCount',[],'samplingInterval',[],'resolutions',[],'channelNames',[]);

    % read EEG properties
    props.channelCount = swapbytes(pnet(con,'read', 1, 'uint32', 'network')); 
    props.samplingInterval = swapbytes(pnet(con,'read', 1, 'double', 'network')); 
    props.resolutions = swapbytes(pnet(con,'read', props.channelCount, 'double', 'network')); %1x64 valori se ho 64 canali
    allChannelNames = pnet(con,'read', hdr.size - 36 - props.channelCount * 8); %228
    props.channelNames = SplitChannelNames(allChannelNames);
end
