function varargout = NeuroOne_TMSEEG_interface(varargin)
% NEUROONE_TMSEEG_INTERFACE MATLAB code for NeuroOne_TMSEEG_interface.fig
%      NEUROONE_TMSEEG_INTERFACE, by itself, creates a new NEUROONE_TMSEEG_INTERFACE or raises the existing
%      singleton*.
%
%      H = NEUROONE_TMSEEG_INTERFACE returns the handle to a new NEUROONE_TMSEEG_INTERFACE or the handle to
%      the existing singleton*.
%
%      NEUROONE_TMSEEG_INTERFACE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEUROONE_TMSEEG_INTERFACE.M with the given input arguments.
%
%      NEUROONE_TMSEEG_INTERFACE('Property','Value',...) creates a new NEUROONE_TMSEEG_INTERFACE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before NeuroOne_TMSEEG_interface_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to NeuroOne_TMSEEG_interface_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help NeuroOne_TMSEEG_interface

% Last Modified by GUIDE v2.5 14-Dec-2020 16:16:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @NeuroOne_TMSEEG_interface_OpeningFcn, ...
    'gui_OutputFcn',  @NeuroOne_TMSEEG_interface_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before NeuroOne_TMSEEG_interface is made visible.
function NeuroOne_TMSEEG_interface_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to NeuroOne_TMSEEG_interface (see VARARGIN)

% Choose default command line output for NeuroOne_TMSEEG_interface
handles.output = hObject;
handles.input2GUI=varargin{1};
handles.chord.chlocs=handles.input2GUI.chord;
handles.chord.ip=handles.input2GUI.ip;
handles.input.slidervector=[0.01:0.01:0.1 0.2:0.1:2]';
handles.overflow=0;
%parametri per il display: se non presente, default,altrimenti cambia taxis
%e yfactor
handles.displayparam.yfactor=100;
handles.displayparam.raw=handles.input2GUI.RAW;
handles.displayparam.avg=handles.input2GUI.AVG;
% gestione canali EOG
handles.EOGchannels=handles.input2GUI.EOG;%vettore con 1 elemento =0 se non ci sono canali EOG, con 1 elemento numerico corrispondente al numero del canale EOG se c'� solo 1 canale EOG, con due elementi numerici se ci sono 2 canali eog - il secondo sottratto al primo
% handles.markername=handles.input2GUI.mrk;
handles.artrej=[-2 5];
handles.ampthresh=100;
handles.lowpass=45;
handles.notch=50;
handles.spm=handles.displayparam.avg;


set(findjobj(handles.pushbutton_start), 'FocusPainted', 0)
set(findjobj(handles.pushbutton_hold), 'FocusPainted', 0)
set(findjobj(handles.pushbutton_ch), 'FocusPainted', 0)
set(findjobj(handles.togglebutton_art), 'FocusPainted', 0)
% set(findjobj(handles.togglebutton_singlepulse), 'FocusPainted', 0)
set(findjobj(handles.togglebutton_pass), 'FocusPainted', 0)
set(findjobj(handles.togglebutton_stop), 'FocusPainted', 0)
set(findjobj(handles.pushbutton_clearavg), 'FocusPainted', 0)
set(findjobj(handles.pushbutton_common), 'FocusPainted', 0)



% Update handles structure
guidata(hObject, handles);

% UIWAIT makes NeuroOne_TMSEEG_interface wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = NeuroOne_TMSEEG_interface_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_start.
function pushbutton_start_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


switch get(handles.pushbutton_start,'String')
    case 'START'
%         set(handles.pushbutton_start,'String','STOP')
        reset_GUI(handles)
        % check coherence btw current data streaming and input montage
        [outval,handles.props,~]=GUI_initialization(handles);
        if outval
            [handles.filters.Bl,handles.filters.Al]=butter(3,handles.lowpass*2/handles.props.srate,'low');
            [handles.filters.Bn,handles.filters.An]=butter(3,[handles.notch-1 handles.notch+1]*2/handles.props.srate,'stop');
            [handles.allch.x,handles.allch.y,handles.allch.w,handles.allch.he]=allchdisplaypos(handles);
            handles.input.timesraw=1000/handles.props.srate:1000/handles.props.srate:handles.displayparam.raw*1000;%time axis of raw plot: starting from 1/srate*1000 to x ms with 1/srate*1000 step
            handles.input.timesavg=[fliplr([0:-1000/handles.props.srate:handles.displayparam.avg(1)]) 1000/handles.props.srate:1000/handles.props.srate:handles.displayparam.avg(2)];%time axis of avg plot: starting from -xxx to xxx ms with 1/srate*1000 step
            handles.input.deltaavg=repmat(handles.allch.y'*handles.displayparam.yfactor,[1 length(handles.input.timesavg)]);
            ySeparation=300;
            handles.input.delta=flipud(repmat([0.5:1:handles.props.nEEG+1.5]'*ySeparation,1,handles.displayparam.raw*handles.props.srate));%EEG + 1EOG + 1trigger by time

            setappdata(handles.togglebutton_pass,'filters',handles.filters)
            
            setappdata(handles.pushbutton_common,'datacom',zeros(size(handles.input.deltaavg)))%%%%%%%%%%%%%SCSCSCSCSCSCSC
            setappdata(handles.pushbutton_common,'datacomst',zeros(size(handles.input.deltaavg)))%%%%%%%%%%%%%SCSCSCSCSCSCSC
            
            handles.props.channelNamesNew(:,1)=[handles.props.channelNames(handles.props.EEG)'; 'EOG'; 'TRIG'];
            %initialization axes_raw
%             set(handles.axes_raw,'XLim',[min(handles.input.timesraw) max(handles.input.timesraw)],'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom
%             set(handles.axes_raw,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))});%
            handles.props.channelNamesNew(:,2)=num2cell(plot(handles.axes_raw,handles.input.timesraw,handles.input.delta','b'));
             set(handles.props.channelNamesNew{end,2},'Color','k')
            set(handles.props.channelNamesNew{end-1,2},'Color','r')
            %initialization axes_avg
            handles.props.channelNamesNew(1:end-1,3)=allchplotavg(handles);
            set(handles.props.channelNamesNew{end-1,3},'Color','r')
            %initialization axes_bfly
             handles.props.channelNamesNew(1:end-1,4)=allchplotsttopo(handles);
            set(handles.props.channelNamesNew{end-1,4},'Color','r')

%             handles.props.channelNamesNew(1:end-2,5)=allchplotbfly(handles);
            %initialization singlepulse
%             handles.props.channelNamesNew(:,6)=num2cell(plot(handles.axes_singlepulse,handles.input.timesavg,handles.input.delta(:,1:length(handles.input.timesavg))','b'));
%             set(handles.props.channelNamesNew{end-1,6},'Color','r')
%             set(handles.props.channelNamesNew{end,6},'Color','k')
%             set(handles.axes_singlepulse,'XLim',handles.spm);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom
            %initialization ch layout
            [handles]=create_figch(handles);%handles.props.channelNamesNew(1:end-2,4)

            setappdata(handles.slider_raw,'props',handles.props)
            setappdata(handles.slider_raw,'input',handles.input)
            
%             pnet('closeall');
            
            [dataavgtoplot,nTrials,nTrials_good]=RdDydata(handles,zeros(length(handles.props.channelNamesNew(:,1)),length(handles.input.timesraw)),zeros(length(handles.props.channelNamesNew(:,1))-1,length(handles.input.timesavg)),ySeparation);
            
        else
%             set(handles.pushbutton_start,'String','START')
            %chiusura GUI?
        end
        %
    case 'STOP'
        set(handles.pushbutton_start,'String','END')
%         pnet('closeall');
        %
end
guidata(hObject, handles);



% --- Executes on button press in pushbutton_hold.
function pushbutton_hold_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_hold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if get(handles.radiobutton_raw,'Value')
    switch get(handles.pushbutton_hold,'String')
        case 'HOLD'
            set(handles.pushbutton_hold,'String','RELEASE')
            set(handles.uitoggletool_mea,'Visible','on')
            setappdata(handles.pushbutton_hold,'datahold',getappdata(handles.pushbutton_common,'dataraw'))
            %
        case 'RELEASE'
            set(handles.pushbutton_hold,'String','HOLD')
            set(handles.uitoggletool_mea,'Visible','off')
            %
    end
end
guidata(hObject, handles);


% --- Executes on button press in pushbutton_ch.
function pushbutton_ch_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%

uistack(getappdata(handles.pushbutton_ch,'figch'),'top')

guidata(hObject, handles);


% --- Executes on button press in togglebutton_pass.
function togglebutton_pass_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton_pass (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton_pass
% 0 unpressed, 1 pressed

switch get(handles.togglebutton_pass,'Value')
    case 1
        handles.togglebutton_pass.BackgroundColor=[1 1 1];
        set(handles.edit_fmax,'Foregroundcolor',[0 0 0])
    case 0
        handles.togglebutton_pass.BackgroundColor=[0.94 0.94 0.94];
        set(handles.edit_fmax,'Foregroundcolor',[0.5 0.5 0.5])
end
if getappdata(handles.pushbutton_common,'trialsgood')
update_avg(handles)
end
update_raw(handles)

guidata(hObject, handles);




function edit_fmax_Callback(hObject, eventdata, handles)
% hObject    handle to edit_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_fmax as text
%        str2double(get(hObject,'String')) returns contents of edit_fmax as a double

props=getappdata(handles.slider_raw,'props');
Hfilters=getappdata(handles.togglebutton_pass,'filters');

if ~isempty(str2num(get(handles.edit_fmax,'String')))
%     if isequal(get(handles.edit_fmax,'Foregroundcolor'),[1 1 1])
        [Hfilters.Bl,Hfilters.Al]=butter(3,str2double(get(handles.edit_fmax,'String'))*2/props.srate,'low');
        setappdata(handles.togglebutton_pass,'filters',Hfilters)
        update_raw(handles)
        if getappdata(handles.pushbutton_common,'trialsgood')
        update_avg(handles)
        end
        %     end
else
    warndlg('Wrong input, frequency setting reset to default!','!! Warning !!')
    set(handles.edit_fmax,'String',num2str(handles.lowpass))
    [Hfilters.Bl,Hfilters.Al]=butter(3,str2double(get(handles.edit_fmax,'String'))*2/props.srate,'low');
    setappdata(handles.togglebutton_pass,'filters',Hfilters)
    update_raw(handles)
    if getappdata(handles.pushbutton_common,'trialsgood')
    update_avg(handles)
    end
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_fmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton_stop.
function togglebutton_stop_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton_stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(handles.togglebutton_stop,'Value')
    case 1
        handles.togglebutton_stop.BackgroundColor=[1 1 1];
        set(handles.edit_fstop,'Foregroundcolor',[0 0 0])
    case 0
        handles.togglebutton_stop.BackgroundColor=[0.94 0.94 0.94];
        set(handles.edit_fstop,'Foregroundcolor',[0.5 0.5 0.5])
end
if getappdata(handles.pushbutton_common,'trialsgood')
update_avg(handles)
end
update_raw(handles)

guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of togglebutton_stop


% --------------------------------------------------------------------


% --- Executes on slider movement.
function slider_raw_Callback(hObject, eventdata, handles)
% hObject    handle to slider_raw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
props=getappdata(handles.slider_raw,'props');
input=getappdata(handles.slider_raw,'input');
% % if get(handles.togglebutton_singlepulse,'Value')%single pulse mode on
% % %     set([props.channelNamesNew{1:end-1,6}],{'YData'},num2cell((cell2mat(get([props.channelNamesNew{1:end-1,6}],{'YData'}))-input.delta(1:end-1,1:length(input.timesavg)))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingSINGLE'))+1)*input.slidervector(round(get(handles.slider_raw,'Value'))+1)+input.delta(1:end-1,1:length(input.timesavg)),2))%SCSCSCSCSC
% %     set([props.channelNamesNew{1:end-1,6}],{'YData'},num2cell((cell2mat(get([props.channelNamesNew{1:end-1,6}],{'YData'}))-input.delta(1:end-1,1:length(input.timesavg)))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingSINGLE')))*input.slidervector(round(get(handles.slider_raw,'Value')))+input.delta(1:end-1,1:length(input.timesavg)),2))
% % 
% %     %     set(handles.axes_singlepulse,'XLim',[-100 100])
% %     setappdata(handles.slider_raw,'CurScalingSINGLE',get(handles.slider_raw,'Value'))
% %     set(handles.text_slidervalue,'String',num2str(input.slidervector(round(get(handles.slider_raw,'Value')))))
% % else
% %     switch get(get(handles.uibuttongroup_display,'SelectedObject'), 'String')
%         case 'RAW'

if get(handles.radiobutton_raw,'Value')
    %         case 'RAW'
    set([props.channelNamesNew{:,2}],{'YData'},num2cell((cell2mat(get([props.channelNamesNew{:,2}],{'YData'}))-input.delta)/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingRAW')))*input.slidervector(round(get(handles.slider_raw,'Value')))+input.delta,2))
    setappdata(handles.slider_raw,'CurScalingRAW',get(handles.slider_raw,'Value'))
    set(handles.text_slidervalue,'String',num2str(input.slidervector(round(get(handles.slider_raw,'Value')))))
elseif get(handles.radiobutton_avg,'Value')
    set([props.channelNamesNew{1:end-1,3}],{'YData'},num2cell((cell2mat(get([props.channelNamesNew{1:end-1,3}],{'YData'}))-input.deltaavg)/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingAVG')))*input.slidervector(round(get(handles.slider_raw,'Value')))+input.deltaavg,2))
    setappdata(handles.slider_raw,'CurScalingAVG',get(handles.slider_raw,'Value'))
    set(handles.text_slidervalue,'String',num2str(input.slidervector(round(get(handles.slider_raw,'Value')))))
elseif get(handles.radiobutton_bfly,'Value')
    set([props.channelNamesNew{1:end-1,4}],{'YData'},num2cell((cell2mat(get([props.channelNamesNew{1:end-1,4}],{'YData'}))-input.deltaavg)/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')))*input.slidervector(round(get(handles.slider_raw,'Value')))+input.deltaavg,2))
    setappdata(handles.slider_raw,'CurScalingBFLY',get(handles.slider_raw,'Value'))
    set(handles.text_slidervalue,'String',num2str(input.slidervector(round(get(handles.slider_raw,'Value')))))
    
    %             set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(cell2mat(get([props.channelNamesNew{1:end-2,5}],{'YData'}))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')))*input.slidervector(round(get(handles.slider_raw,'Value'))),2))
    % %             set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(cell2mat(get([props.channelNamesNew{1:end-2,5}],{'YData'}))/handles.input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')))*handles.input.slidervector(round(get(handles.slider_raw,'Value'))),2))
    %             setappdata(handles.slider_raw,'CurScalingBFLY',get(handles.slider_raw,'Value'))
    %             set(handles.text_slidervalue,'String',num2str(input.slidervector(round(get(handles.slider_raw,'Value')))))
    %     end
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider_raw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_raw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in togglebutton_art.
function togglebutton_art_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton_art (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(handles.togglebutton_art,'Value')
    case 1
        set(handles.edit_tmin,'Foregroundcolor',[0 0 0])
        set(handles.edit_tmax,'Foregroundcolor',[0 0 0])
        handles.togglebutton_art.BackgroundColor=[1 1 1];
    case 0
        handles.togglebutton_art.BackgroundColor=[0.94 0.94 0.94];
        set(handles.edit_tmin,'Foregroundcolor',[0.5 0.5 0.5])
        set(handles.edit_tmax,'Foregroundcolor',[0.5 0.5 0.5])
end

update_raw(handles)
% update_singlepulse(handles,1)
if getappdata(handles.pushbutton_common,'trialsgood')
update_avg(handles)
end

guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of togglebutton_art



function edit_tmin_Callback(hObject, eventdata, handles)
% hObject    handle to edit_tmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_tmin as text
%        str2double(get(hObject,'String')) returns contents of edit_tmin as a double
if ~isempty(str2num(get(handles.edit_tmin,'String')))
    if isequal(get(handles.edit_tmin,'Foregroundcolor'),[0 0 0])
        if getappdata(handles.pushbutton_common,'trialsgood')
        update_avg(handles)
        end
        update_raw(handles)
    end
else
    warndlg('Wrong input, time setting reset to default!','!! Warning !!')
    set(handles.edit_tmin,'String',num2str(handles.artrej(1)))
    if getappdata(handles.pushbutton_common,'trialsgood')
    update_avg(handles)
    end
    update_raw(handles)
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_tmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_tmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_tmax_Callback(hObject, eventdata, handles)
% hObject    handle to edit_tmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_tmax as text
%        str2double(get(hObject,'String')) returns contents of edit_tmax as a double
if ~isempty(str2num(get(handles.edit_tmax,'String')))
    if isequal(get(handles.edit_tmax,'Foregroundcolor'),[0 0 0])
        if getappdata(handles.pushbutton_common,'trialsgood')
        update_avg(handles)
        end
        update_raw(handles)
    end
else
    warndlg('Wrong input, time setting reset to default!','!! Warning !!')
    set(handles.edit_tmax,'String',num2str(handles.artrej(2)))
    if getappdata(handles.pushbutton_common,'trialsgood')
    update_avg(handles)
    end
    update_raw(handles)
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_tmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_tmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_common.
function pushbutton_common_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_common (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(handles.radiobutton_raw,'Value')==0
switch get(handles.pushbutton_common,'String')
    case 'COM ref'
        set(handles.pushbutton_common,'String','AVG ref')
        set(handles.uipanel_axesavg,'Title','AVERAGE data in COM ref')
        set(handles.uipanel_axesbfly,'Title','SINGLE-TRIAL data in COM ref')
    case 'AVG ref'
        set(handles.pushbutton_common,'String','COM ref')
        set(handles.uipanel_axesavg,'Title','AVERAGE data in AVG ref')
        set(handles.uipanel_axesbfly,'Title','SINGLE-TRIAL data in AVG ref')
end
% if getappdata(handles.pushbutton_common,'trialsgood')
update_avg(handles)
% end
end
guidata(hObject, handles);

% --- Executes on button press in pushbutton_clearavg.
function pushbutton_clearavg_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_clearavg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
button = questdlg({'You are about to CLEAR THE AVERAGE. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
    props=getappdata(handles.slider_raw,'props');
    input=getappdata(handles.slider_raw,'input');
%     save_clearedAVG(handles,props,input);
    set([props.channelNamesNew{1:end-1,3}],{'YData'},num2cell(cell2mat(get([props.channelNamesNew{1:end-1,3}],{'YData'}))*0+input.deltaavg,2))
%     set([props.channelNamesNew{1:end-1,4}],{'YData'},num2cell(cell2mat(get([props.channelNamesNew{1:end-1,4}],{'YData'}))*0+input.deltaavg,2))
%     set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(cell2mat(get([props.channelNamesNew{1:end-2,5}],{'YData'}))*0,2))
    set(handles.text_trials,'String',strcat(num2str(0),'/',num2str(0)));
    setappdata(handles.pushbutton_common,'trialsgood',0)
    setappdata(handles.pushbutton_common,'trials',0)
    setappdata(handles.pushbutton_common,'datacom',zeros(size(input.deltaavg)))
%     setappdata(handles.slider_raw,'CurScalingAVG',find(handles.input.slidervector==1))
%     setappdata(handles.slider_raw,'CurScalingBFLY',find(handles.input.slidervector==1))
end

guidata(hObject, handles);




% --- Executes on button press in togglebutton_ampthresh.
function togglebutton_ampthresh_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton_ampthresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
switch get(handles.togglebutton_ampthresh,'Value')
    case 1
        handles.togglebutton_ampthresh.BackgroundColor=[1 1 1];
        set(handles.edit_thresh,'Foregroundcolor',[0 0 0])
    case 0
        handles.togglebutton_ampthresh.BackgroundColor=[0.94 0.94 0.94];
        set(handles.edit_thresh,'Foregroundcolor',[0.5 0.5 0.5])
end
guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of togglebutton_ampthresh



function edit_thresh_Callback(hObject, eventdata, handles)
% hObject    handle to edit_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_thresh as text
%        str2double(get(hObject,'String')) returns contents of edit_thresh as a double
if isempty(str2num(get(handles.edit_thresh,'String')))
    warndlg('Wrong input, threshold setting reset to default!','!! Warning !!')
    set(handles.edit_thresh,'String',num2str(handles.ampthresh))
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_thresh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function edit_fstop_Callback(hObject, eventdata, handles)
% hObject    handle to edit_fstop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_fstop as text
%        str2double(get(hObject,'String')) returns contents of edit_fstop as a double

props=getappdata(handles.slider_raw,'props');
Hfilters=getappdata(handles.togglebutton_pass,'filters');

if ~isempty(str2num(get(handles.edit_fstop,'String')))
%     if isequal(get(handles.edit_fstop,'Foregroundcolor'),[1 1 1])
        [Hfilters.Bn,Hfilters.An]=butter(3,[str2double(get(handles.edit_fstop,'String'))-1 str2double(get(handles.edit_fstop,'String'))+1]*2/props.srate,'stop');
        setappdata(handles.togglebutton_stop,'filters',Hfilters)
        if getappdata(handles.pushbutton_common,'trialsgood')
        update_avg(handles)
        end
        update_raw(handles)
%     end
else
    warndlg('Wrong input, time setting reset to default!','!! Warning !!')
    set(handles.edit_fstop,'String',num2str(handles.notch))
    [Hfilters.Bn,Hfilters.An]=butter(3,[str2double(get(handles.edit_fstop,'String'))-1 str2double(get(handles.edit_fstop,'String'))+1]*2/props.srate,'stop');
    setappdata(handles.togglebutton_stop,'filters',Hfilters)
    if getappdata(handles.pushbutton_common,'trialsgood')
    update_avg(handles)
    end
    update_raw(handles)
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_fstop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_fstop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton_singlepulse.
% function togglebutton_singlepulse_Callback(hObject, eventdata, handles)
% % hObject    handle to togglebutton_singlepulse (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hint: get(hObject,'Value') returns toggle state of togglebutton_singlepulse
% 
% switch get(handles.togglebutton_singlepulse,'Value')
%     case 1
%         update_singlepulse(handles,0)
%         handles.togglebutton_pass.BackgroundColor=[1 1 1];
%         set(handles.togglebutton_singlepulse,'String','STOP SINGLE PULSE mode')
%         set(handles.uipanel_singlepulse,'Visible','on')
%         set(handles.uipanel_axesbfly,'Visible','off')
%         set(handles.uipanel_axesavg,'Visible','off')
%         set(handles.uipanel_axesraw,'Visible','off')
%         set(handles.panelavg,'Visible','off')
%         set(handles.pushbutton_hold,'Visible','off')
%         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingSINGLE'))
%     case 0
%         handles.togglebutton_pass.BackgroundColor=[0.94 0.94 0.94];
%         set(handles.togglebutton_singlepulse,'String','START SINGLE PULSE mode')
%         set(handles.uipanel_singlepulse,'Visible','off')
%         
%         switch get(get(handles.uibuttongroup_display,'SelectedObject'), 'String')
%             case 'BFLY'
%                 set(handles.uipanel_axesbfly,'Visible','on')
%                 if strcmp(get(handles.pushbutton_common,'String'),'COM ref')
%                     set(handles.uipanel_axesbfly,'Title','BUTTERFLY plot of AVERAGE data in AVG ref')
%                 else
%                     set(handles.uipanel_axesbfly,'Title','BUTTERFLY plot of AVERAGE data in COM ref')
%                 end
%                 set(handles.panelavg,'Visible','on')
%                 set(handles.uipanel_axesavg,'Visible','off')
%                 set(handles.uipanel_axesraw,'Visible','off')
%                 set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingBFLY'))
%             case 'RAW'
%                 set(handles.uipanel_axesavg,'Visible','off')
%                 set(handles.uipanel_axesraw,'Visible','on')
%                 set(handles.uipanel_axesbfly,'Visible','off')
%                 set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingRAW'))
%                 set(handles.panelavg,'Visible','off')
%                 set(handles.pushbutton_hold,'Visible','on')
%             case 'AVG'
%                 set(handles.uipanel_axesavg,'Visible','on')
%                 if strcmp(get(handles.pushbutton_common,'String'),'COM ref')
%                     set(handles.uipanel_axesavg,'Title','AVERAGE data in AVG ref')
%                 else
%                     set(handles.uipanel_axesavg,'Title','AVERAGE data in COM ref')
%                 end
%                 set(handles.uipanel_axesraw,'Visible','off')
%                 set(handles.uipanel_axesbfly,'Visible','off')
%                 set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingAVG'))
%                 set(handles.panelavg,'Visible','on')
%                 set(handles.pushbutton_hold,'Visible','off')
%         end
% end
% 
% 
% guidata(hObject, handles);
% 

% --- Executes on button press in radiobutton_raw.
function radiobutton_raw_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_raw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% uibuttongroup_display_SelectionChangedFcn(hObject, eventdata, handles)
if get(handles.radiobutton_raw,'Value')==1
    set(handles.radiobutton_avg,'Value',0)
    set(handles.radiobutton_bfly,'Value',0)
    set(handles.uipanel_axesraw,'Visible','on')
    set(handles.pushbutton_hold,'String','HOLD')
    set(handles.uipanel_axesavg,'Visible','off')
    set(handles.uipanel_axesbfly,'Visible','off')
    set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingRAW'))
    set(handles.text_slidervalue,'String',num2str(handles.input.slidervector(round(get(handles.slider_raw,'Value')))))
end

% Hint: get(hObject,'Value') returns toggle state of radiobutton_raw
guidata(hObject, handles);


% --- Executes on button press in radiobutton_avg.
function radiobutton_avg_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_avg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% uibuttongroup_display_SelectionChangedFcn(hObject, eventdata, handles)
if get(handles.radiobutton_avg,'Value')==1
    set(handles.radiobutton_raw,'Value',0)
    set(handles.radiobutton_bfly,'Value',0)
    set(handles.uipanel_axesavg,'Visible','on')
%     set(handles.uipanel_axesraw,'Visible','off')
    set(handles.uipanel_axesbfly,'Visible','off')
    set(handles.uitoggletool_mea,'Visible','on')
    set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingAVG'))
    set(handles.text_slidervalue,'String',num2str(handles.input.slidervector(round(get(handles.slider_raw,'Value')))))
    set(handles.pushbutton_common,'String','COM ref')
update_avg(handles)
end

% Hint: get(hObject,'Value') returns toggle state of radiobutton_avg
guidata(hObject, handles);


% --- Executes on button press in radiobutton_bfly.
function radiobutton_bfly_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_bfly (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% uibuttongroup_display_SelectionChangedFcn(hObject, eventdata, handles)
if get(handles.radiobutton_bfly,'Value')==1
    set(handles.radiobutton_avg,'Value',0)
    set(handles.radiobutton_raw,'Value',0)
    set(handles.uipanel_axesavg,'Visible','on')
    set(handles.uipanel_axesbfly,'Visible','on')
%     set(handles.uipanel_axesraw,'Visible','off')
    set(handles.uitoggletool_mea,'Visible','on')
    set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingBFLY'))
    set(handles.text_slidervalue,'String',num2str(handles.input.slidervector(round(get(handles.slider_raw,'Value')))))
    set(handles.pushbutton_common,'String','COM ref')
    update_avg(handles)
end

% Hint: get(hObject,'Value') returns toggle state of radiobutton_bfly
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
% function uibuttongroup_display_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to uibuttongroup_display (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% guidata(hObject, handles);


% --- Executes when selected object is changed in uibuttongroup_display.
% function uibuttongroup_display_SelectionChangedFcn(hObject, eventdata, handles)
% % hObject    handle to the selected object in uibuttongroup_display 
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% switch get(get(handles.uibuttongroup_display,'SelectedObject'), 'String')
%     case 'RAW'
%         set(handles.togglebutton_singlepulse,'String','START SINGLE PULSE mode')
%         set(handles.uipanel_axesavg,'Visible','off')
%         set(handles.uipanel_axesraw,'Visible','on')
%         set(handles.uitoggletool_mea,'Visible','off')
%         set(handles.uipanel_axesbfly,'Visible','off')
%         set(handles.uipanel_singlepulse,'Visible','off')
%         set(handles.togglebutton_singlepulse,'Value',0)
%         set(handles.panelavg,'Visible','off')
%         set(handles.pushbutton_hold,'Visible','on')
%         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingRAW'))
%     case 'AVG'
%         set(handles.uipanel_axesavg,'Visible','on')
%         set(handles.uitoggletool_mea,'Visible','on')
%         set(handles.togglebutton_singlepulse,'String','START SINGLE PULSE mode')
%         if strcmp(get(handles.pushbutton_common,'String'),'COM ref')
%             set(handles.uipanel_axesavg,'Title','AVERAGE data in AVG ref')
%         else 
%             set(handles.uipanel_axesavg,'Title','AVERAGE data in COM ref')
%         end
%         set(handles.uipanel_axesraw,'Visible','off')
%         set(handles.uipanel_axesbfly,'Visible','off')
%         set(handles.uipanel_singlepulse,'Visible','off')
%         set(handles.togglebutton_singlepulse,'Value',0)
%         set(handles.pushbutton_hold,'Visible','off')
%         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingAVG'))
%         set(handles.panelavg,'Visible','on')
%     case 'BFLY'
%         set(handles.uipanel_axesavg,'Visible','off')
%         set(handles.uitoggletool_mea,'Visible','on')
%         set(handles.togglebutton_singlepulse,'String','START SINGLE PULSE mode')
%         set(handles.uipanel_axesraw,'Visible','off')
%         set(handles.uipanel_axesbfly,'Visible','on')
%         if strcmp(get(handles.pushbutton_common,'String'),'COM ref')
%             set(handles.uipanel_axesbfly,'Title','BUTTERFLY plot of AVERAGE data in AVG ref')
%         else
%             set(handles.uipanel_axesbfly,'Title','BUTTERFLY plot of AVERAGE data in COM ref')
%         end
%         set(handles.uipanel_singlepulse,'Visible','off')
%         set(handles.togglebutton_singlepulse,'Value',0)
%         set(handles.pushbutton_hold,'Visible','off')
%         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingBFLY'))
%         set(handles.panelavg,'Visible','on')
% end
% guidata(hObject, handles);
