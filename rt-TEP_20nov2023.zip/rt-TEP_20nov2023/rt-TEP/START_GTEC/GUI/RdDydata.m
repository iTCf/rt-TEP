function [dataavgtoplot,nTrials,nTrials_good]=RdDydata(handles,datarawtoplot,dataavgtoplot,ySeparation)

set(handles.axes_raw,'XLim',[min(handles.input.timesraw) max(handles.input.timesraw)],'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom
set(handles.axes_raw,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'XLim',handles.spm,'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom

handles.zoom_obj = zoom(handles.figure1);
handles.dcm_obj=datacursormode(handles.figure1);
set(handles.dcm_obj,'DisplayStyle','window')
set(handles.dcm_obj,'UpdateFcn',{@mydata_cursor,handles})

nTrials_good=getappdata(handles.pushbutton_common,'trialsgood');
nTrials=getappdata(handles.pushbutton_common,'trials');


% disp('Loading the library...');
% lib = lsl_loadlib();
% disp('Resolving an EEG stream...');
% result = {};
% while isempty(result)
%     result = lsl_resolve_byprop(lib,'type','EEG'); end
% disp('Opening an inlet...');
% inlet = lsl_inlet(result{1});
% disp('Now receiving chunked data...');
% streaminfos = lsl_resolve_all(lib,1);
% pause(0.5)
tic
% [chunk,stamps] = inlet.pull_chunk();
% % chunk=chunk*1000000;
% if isempty(chunk)
%     while isempty(chunk) && toc<5
%         [chunk,stamps] = inlet.pull_chunk();
% %         chunk=chunk*1000000;
%     end
% end
% if isempty(chunk)
%     msgbox('Incoming data empty! Closing...','Error','error');
% else
%     msgbox('Start receiving data ...');
% end
% 
% GThandle = gUDPinit(51422);
% GThandle = gUDPinit(51422);
chunk = gUDPrecv(handles.input2GUI.socket,100000000);
 if isempty(chunk)
    while isempty(chunk) && toc<5
        chunk = gUDPrecv(handles.input2GUI.socket,100000000);
%         chunk=chunk*1000000;
    end
end
if isempty(chunk)
    msgbox('Incoming data empty! Closing...','Error','error');
    succeed = gUDPcloseALL;
else
    msgbox('Start receiving data ...');
end

indx=[];
tmptmptmp=clock;
dataavgtmp=zeros(handles.props.nEEG+1,length(handles.input.timesavg));
chunk = gUDPrecv(handles.input2GUI.socket,handles.props.srate/1000*10);
while ~isempty(chunk) && strcmp(get(handles.pushbutton_start,'String'),'STOP')
    chunk=cell2mat(chunk')';
% chunk=transpose(chunk);

%     chunk=chunk*1000000;
    if size(chunk,2)>size(datarawtoplot,2)
        chunk=chunk(:,size(chunk,2)-size(datarawtoplot,2)+1:end);
    end
    
    datarawtoplot(1:end-2,1:size(chunk,2))=chunk(handles.props.EEG,:);%EEG channels
    %     datarawtoplot(:,1:size(chunk,2))=chunk([1:31 33:64 32 89],:);
    %EOG channels
    if length(handles.EOGchannels)==1
        switch handles.EOGchannels
            case 0
                datarawtoplot(end-1,1:size(chunk,2))=0;
            otherwise
                datarawtoplot(end-1,1:size(chunk,2))=chunk(handles.EOGchannels,:);
        end
    else datarawtoplot(end-1,1:size(chunk,2))=chunk(handles.EOGchannels(2),:)-chunk(handles.EOGchannels(1),:);
    end
    datarawtoplot(end,1:size(chunk,2))=chunk(end,:);%trigger!!!!!!!
%     find(chunk(end))
    datarawtoplot=circshift(datarawtoplot,[0 -size(chunk,2)]);
indx=find(diff(datarawtoplot(end,:))>0)+1;
datarawtoplot(end,setdiff([1:size(datarawtoplot,2)],indx))=0;
    %     indx=find(datarawtoplot(end,:));
    %     tmp1=etime(clock,tmptmptmp);
    %     if tmp1(end)>3
    %         indx=size(datarawtoplot,2)-1000;
    %         tmptmptmp=clock;
    %     end
    setappdata(handles.pushbutton_common,'dataraw',datarawtoplot);
    update_raw(handles)
 
    if ~isempty(indx)
        for jj=1:length(indx)
            if indx(jj)<length(find(handles.input.timesavg<0))
                datarawtoplot(end,indx(jj))=0;
            elseif indx(jj)<size(datarawtoplot,2)-length(find(handles.input.timesavg>0))
                datarawtoplot(end,indx(jj))=0;
                dataavgtmp=datarawtoplot(1:handles.props.nEEG+1,indx(jj)-length(find(handles.input.timesavg<0)):indx(jj)+length(find(handles.input.timesavg>0)));
                dataavgtmp=dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-floor(0.01*handles.props.srate)),2),[1,size(dataavgtmp,2)]);%bl correction
                nTrials=getappdata(handles.pushbutton_common,'trials')+1;
                setappdata(handles.pushbutton_common,'trials',nTrials);
                
                 if nTrials==1
                        dataavgtoplot=zeros(size(dataavgtmp));
                    else
                    dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
                 end
                    
                 setappdata(handles.pushbutton_common,'datacomst',dataavgtmp)%SCSCSCSCSC
                 
%                 dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
                
                switch get(handles.togglebutton_ampthresh,'Value')
                    case 1
                        if max(abs(dataavgtmp(end,:)))<abs(str2double(get(handles.edit_thresh,'String')))
                            dataavgtoplot=dataavgtoplot+dataavgtmp;
                            datarawtoplot(end,indx(jj))=0;
                            nTrials_good= getappdata(handles.pushbutton_common,'trialsgood')+1;
                            setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                        end
                    case 0
                        dataavgtoplot=dataavgtoplot+dataavgtmp;
                        datarawtoplot(end,indx(jj))=0;
                        nTrials_good= getappdata(handles.pushbutton_common,'trialsgood')+1;
                        setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                end
                 %in questo caso dataavgtmp deve contenere solo 1 trial
%                     if get(handles.togglebutton_singlepulse,'Value')
%                         setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
%                         update_singlepulse(handles,1)
%                     end
%                     
            end
        end
        setappdata(handles.pushbutton_common,'datacom',dataavgtoplot)
%         %in questo caso dataavgtmp deve contenere solo 1 trial
%         if get(handles.togglebutton_singlepulse,'Value')
%             setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
%             update_singlepulse(handles,1)
%         end
        if getappdata(handles.pushbutton_common,'trialsgood')
            update_avg(handles)
        end
        set(handles.text_trials,'String',strcat(num2str(getappdata(handles.pushbutton_common,'trialsgood')),'/',num2str(getappdata(handles.pushbutton_common,'trials'))));
        
    end
    indx=[];
    %plot(eeg)
    %     eeg=yc(1:tc,indx+tavg_min/1000*sr:indx+tavg_max/1000*sr);
    %     set([h_raw{:,1}],{'YData'},num2cell(((yc-repmat(mean(yc,2),[1,size(yc,2)]))+Yc),2));%plot raw data
    %     set([h_avg{:,1}],{'YData'},num2cell(((eeg_chunk-repmat(mean(eeg_chunk,2),[1,size(eeg_chunk,2)]))/nTrials),2));%plot avg data
    %     drawnow
    
chunk = gUDPrecv(handles.input2GUI.socket,handles.props.srate/1000*10);
 if isempty(chunk)
    while isempty(chunk)
        chunk = gUDPrecv(handles.input2GUI.socket,handles.props.srate/1000*10)
    end
 end
end
