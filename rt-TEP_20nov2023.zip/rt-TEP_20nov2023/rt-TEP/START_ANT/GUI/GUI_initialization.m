function [outval,props_out,lib,datahdr]=GUI_initialization(handles)
datahdr=[];
outval=0;
props_out=[];
h=waitbar(0,'Starting ...');
% header_size = 24;
% tryheader=[];
props.channelNames={handles.chord.chlocs.labels};%%%%%%%%%%%%%%%%%check
                % Read and display recording parameters
%                 addpath('C:\Users\neuro\Desktop\GUINUOVA\tips');
disp('Loading the library...');
lib = lsl_loadlib();
disp('Resolving an EEG stream...');
result = {};
while isempty(result)
    result = lsl_resolve_byprop(lib,'type','EEG'); end
disp('Opening an inlet...');
inlet = lsl_inlet(result{1});
disp('Now receiving chunked data...');
streaminfos = lsl_resolve_all(lib,1);
% props.srate= lsl_get_nominal_srate(streaminfos{1,2}.LibHandle,streaminfos{1,2}.InfoHandle) ;
props.srate=handles.input2GUI.srate;% props.srate=4000;% 
% props.srate=sr;
set(handles.text_sr,'String', num2str(props.srate));
props.EEG=find(cellfun(@(x) strcmp(x,'EEG'),{handles.chord.chlocs.type}));
props.resolutions=1;
% if length(unique(props.resolutions))==1
%     set(handles.text_ampres,'String', num2str(props.resolutions(1)))
% else
%     set(handles.text_ampres,'String', 'var.')
% end
% if length(unique(props.resolutions(props.EEG)))==1
%     props.resolutionEEG=props.resolutions(props.EEG(1));
% else
%     msgbox('EEG channels have different resolutions!','Error','error');
%     close(h)
%     % uscire!!!!
% end
props.nEEG=length(props.EEG);%%%%%%%%%%%%%%%%%%%%%%%%%%
props.nEOG=length(find(cellfun(@(x) strcmp(x,'EOG'),{handles.chord.chlocs.type})));
set(handles.text_eegch,'String',num2str(props.nEEG))
set(handles.text_eogch,'String',num2str(props.nEOG))
set(handles.text_addch,'String',num2str(length(find(cellfun(@(x) strcmp(x,'other'),{handles.chord.chlocs.type})))))
%check correspondence with input montage
% if props.channelCount~=size(handles.chord.chlocs,2)
%     msgbox('the number of received channels does not match input montage!','Error','error');
%     close(h)
%     % uscire!!!!
% end
% if ~isequal(props.channelNames,{handles.chord.chlocs.labels})
%     msgbox('the labels of received channels do not match input montage!','Error','error');
%     close(h)
%     % uscire!!!!
% end
props_out=props;
close(h)
set(handles.panelacq,'Visible','on')
set(handles.text_slidervalue,'String', num2str(1))
outval=1;


