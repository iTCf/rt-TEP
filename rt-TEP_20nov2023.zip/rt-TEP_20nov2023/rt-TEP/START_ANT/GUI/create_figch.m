function [handles]=create_figch(handles)

handles.figch=figure;
setappdata(handles.pushbutton_ch,'figch',handles.figch);
set(handles.figch,'Color',[1 1 1],'NumberTitle','off','Name','Click to select a channel: Green=ACCEPT; Red=REJECT','DockControls','off','MenuBar','none','Visible','on','CloseRequestFcn',@closereq_ch)
h=cell(1,handles.props.nEEG);
t=cell(1,handles.props.nEEG);
for ch=1:handles.props.nEEG
    h{1,ch}=axes('position',[handles.allch.x(ch) handles.allch.y(ch) handles.allch.w*1.5 handles.allch.he*1.5],'Color','g',...
        'ycolor','none',...
        'xcolor','none',...
        'PickableParts','all','visible','on','tag',handles.props.channelNamesNew{ch,1});
    axis square
    set(h{1,ch},'ButtonDownFcn',@(~,~)getCHtag(h{1,ch},handles),'HitTest','on')
    t{1,ch}=text(0.5,0.5,handles.props.channelNamesNew{ch,1},'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',8);
    set(t{1,ch},'ButtonDownFcn',@(~,~)getCHtag(h{1,ch},handles),'HitTest','on')
end
handles.props.channelNamesNew(1:end-2,5)=h;
uistack(handles.figch,'bottom')