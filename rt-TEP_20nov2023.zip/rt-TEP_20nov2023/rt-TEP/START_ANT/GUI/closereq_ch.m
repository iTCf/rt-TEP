function closereq_ch(figch,~)



button = questdlg({'You are about to close CHANNEL MAP. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
%     setappdata(g,'open',0)
    delete(figch)
% set(g,'Visible','off')
else uistack(figch,'bottom')
end
