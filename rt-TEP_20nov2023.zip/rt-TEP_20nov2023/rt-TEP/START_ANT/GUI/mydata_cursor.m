function output_txt=mydata_cursor(~,event_obj,handles)%,handles)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).

props=getappdata(handles.slider_raw,'props');
input=getappdata(handles.slider_raw,'input');

position = get(event_obj,'Position');
target=get(event_obj,'Target');
% if get(handles.togglebutton_singlepulse,'Value')
%     chname=cell2mat(props.channelNamesNew(find([props.channelNamesNew{1:end,6}]==target),1));
%     champ=((position(2)-input.delta(find([props.channelNamesNew{1:end,6}]==target),1))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingSINGLE'))));%/10;
%     chtime=position(1);
% else
%     switch get(get(handles.uibuttongroup_display,'SelectedObject'), 'String')
%         case 'RAW'
if get(handles.radiobutton_raw,'Value')
    if strcmp(get(handles.pushbutton_hold,'String'),'RELEASE')
        chname=props.channelNamesNew(find([props.channelNamesNew{1:end,2}]==target),1);
        champ=(position(2)-input.delta(find([props.channelNamesNew{1:end,2}]==target),1))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingRAW')));
        chtime=position(1);
    else
        %                 msgbox('Cannot measure scrolling EEG traces!','Warning','warn');
    end
    %         case 'AVG'
elseif get(handles.radiobutton_avg,'Value')
    chname=props.channelNamesNew(find([props.channelNamesNew{1:end-1,3}]==target),1);
    champ=(position(2)-input.deltaavg(find([props.channelNamesNew{1:end-1,3}]==target),1))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingAVG')));
    chtime=((position(1)-handles.allch.x(find([props.channelNamesNew{1:end-1,3}]==target)))/(handles.allch.w/length(handles.input.timesavg))+1)/handles.props.srate*1000+handles.displayparam.avg(1);
    %         case 'BFLY'
elseif get(handles.radiobutton_bfly,'Value')
    chname=props.channelNamesNew(find([props.channelNamesNew{1:end-1,4}]==target),1);
    champ=(position(2)-input.deltaavg(find([props.channelNamesNew{1:end-1,4}]==target),1))/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')));
    chtime=((position(1)-handles.allch.x(find([props.channelNamesNew{1:end-1,4}]==target)))/(handles.allch.w/length(handles.input.timesavg))+1)/handles.props.srate*1000+handles.displayparam.avg(1);
    
    
    %     chname=props.channelNamesNew(find([props.channelNamesNew{1:end-2,4}]==target),1);
    %             champ=position(2)/input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY')));
    %             chtime=position(1);
end
% end

output_txt = {['Time: ',num2str(round(chtime)),' ms'],['Volt: ',num2str(champ,'%.1f'),' �V'],['Channel: ',char(chname)]};
% output_txt = {['Time: ',num2str(chtime,1),' ms'],['Volt: ',num2str(champ,1),' �V']};


