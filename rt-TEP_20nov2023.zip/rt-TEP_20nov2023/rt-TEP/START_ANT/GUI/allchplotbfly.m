% function [h_bfly]=allchplotbfly(handles)
% 
% hold(handles.axes_bfly,'on')
% h_bfly=cell(handles.props.nEEG,1);
% for jj=1:handles.props.nEEG
%     h_bfly(jj,1)=num2cell(plot(handles.input.timesavg,zeros(length(handles.input.timesavg),1),'Color','b','DisplayName',handles.props.channelNamesNew{jj,1}));
% end
% hold(handles.axes_bfly,'off')
%  grid(handles.axes_bfly,'on')
% set(handles.axes_bfly,'Ylim',[-20 20])
