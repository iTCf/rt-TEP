function [h_avg]=allchplotsttopo(handles)

hold(handles.axes_bfly,'on')
tmptmp=find(handles.input.timesavg==0);
h_avg=cell(length(handles.allch.x),1);
for jj=1:length(handles.allch.x)
    tmp=handles.allch.x(jj):handles.allch.w/length(handles.input.timesavg):handles.allch.x(jj)+handles.allch.w-handles.allch.w/length(handles.input.timesavg);
    h_avg(jj,1)=num2cell(plot(handles.axes_bfly,tmp,zeros(size(tmp,2),1)+handles.allch.y(jj)*handles.displayparam.yfactor,'DisplayName',handles.props.channelNamesNew{jj,1},'LineWidth',1,'Color','b','Visible','on'));
    line([tmp(1) tmp(end)],[handles.allch.y(jj)*handles.displayparam.yfactor handles.allch.y(jj)*handles.displayparam.yfactor],'Color',[0.4 0.4 0.4],'Parent',handles.axes_bfly);
    line([tmp(tmptmp) tmp(tmptmp)],[handles.allch.y(jj)*handles.displayparam.yfactor-5 handles.allch.y(jj)*handles.displayparam.yfactor+5],'Color',[0.4 0.4 0.4],'Parent',handles.axes_bfly);
end
hold(handles.axes_bfly,'off')
Y=handles.allch.y(find(handles.allch.y==min(handles.allch.y)))*handles.displayparam.yfactor-max(diff(sort(handles.allch.y)))*handles.displayparam.yfactor;
set(handles.axes_bfly,'YLim',[Y(1) handles.allch.y(find(handles.allch.y==max(handles.allch.y)))*handles.displayparam.yfactor+max(diff(sort(handles.allch.y)))*handles.displayparam.yfactor])
























% 
% for jj=1:length(handles.allch.x)
%     tmp=handles.allch.x(jj):handles.allch.w/length(handles.input.timesavg):handles.allch.x(jj)+handles.allch.w-handles.allch.w/length(handles.input.timesavg);
%     h_avg(jj,1)=num2cell(plot(tmp,zeros(size(tmp,2),1)+handles.allch.y(jj)*handles.displayparam.yfactor,'DisplayName',handles.props.channelNamesNew{jj,1},'LineWidth',2));
%     line([tmp(1) tmp(end)],[handles.allch.y(jj)*handles.displayparam.yfactor handles.allch.y(jj)*handles.displayparam.yfactor]);
%     line([tmp(tmptmp) tmp(tmptmp)],[handles.allch.y(jj)*handles.displayparam.yfactor-10 handles.allch.y(jj)*handles.displayparam.yfactor+10]);
% end
