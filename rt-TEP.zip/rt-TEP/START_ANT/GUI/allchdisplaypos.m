function [x,y,w,he]=allchdisplaypos(handles)


tmp=find(cellfun(@(x) strcmp(x,'EEG'),{handles.chord.chlocs.type}));

Th=[handles.chord.chlocs(tmp).theta];
Rd=[handles.chord.chlocs(tmp).radius];
Th = pi/180*Th;
[x,y] = pol2cart(Th,Rd);
rotate = 3*pi/2;
allcoords = (y + x*sqrt(-1))*exp(sqrt(-1)*rotate);
% w=0.07;
% he=0.05;
x = imag(allcoords);
y = real(allcoords);
x=(1-(x-min(x)));
x=(x-min(x));
x=x/max(x);
y=(y-min(y));
y=y/max(y);

d = dist([x;y]);
for i=1:size(x,2)
    d(i,i) = inf; % exclude the diagonal
end
mindist = min(d(:));
w= mindist * 0.8;
he = mindist * 0.6;

y=y/(1+2*he)+he/2;
x=x/(1+2*w)+w/2;

x=[x 0];%manual setting of EOG channel location
y=[y 1];%manual setting of EOG channel location



