function[]=getCHtag(h,handles)
% assignin('base','ch_sel',h.Tag);
tmp=get(h,'Color');
props=getappdata(handles.slider_raw,'props');
input=getappdata(handles.slider_raw,'input');
dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');
nTrials_good=getappdata(handles.pushbutton_common,'trialsgood');

if isequal(tmp,[0 1 0])
    set(h,'Color','r')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),2},'Visible','off')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),3},'Visible','off')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),4},'Visible','off')
%     set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),5},'Visible','off')
%     set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),6},'Visible','off')
    
    %     assignin('base','colore','r');
elseif isequal(tmp,[1 0 0])
    set(h,'Color','g')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),2},'Visible','on')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),3},'Visible','on')
    set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),4},'Visible','on')
%     set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),5},'Visible','on')
%     set(handles.props.channelNamesNew{strcmp(handles.props.channelNamesNew(:,1),get(h,'tag')),6},'Visible','on')
    
    %     assignin('base','colore','g');
end

if nTrials_good
update_avg(handles)
end

% switch get(handles.pushbutton_common,'String')
%     case 'COM ref'
%         tmp2=strcmp(get([props.channelNamesNew{1:end-2,3}],'Visible'),'on');
%         datatmp=dataavgtoplot-repmat(mean(dataavgtoplot(tmp2,:),1),[size(dataavgtoplot,1),1]);
%         datatmp(end,:)=dataavgtoplot(end,:);
%         set([props.channelNamesNew{1:end-1,3}],{'YData'},num2cell(datatmp*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingAVG'))+1)/nTrials_good+input.deltaavg,2));%plot raw data
%         set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(datatmp(1:end-1,:)*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY'))+1)/nTrials_good,2));%plot raw data
%     case 'AVG ref'
%         set([props.channelNamesNew{1:end-1,3}],{'YData'},num2cell(dataavgtoplot*handles.input.slidervector(round(getappdata(handles.slider_raw,'CurScalingAVG'))+1)/nTrials_good+input.deltaavg,2))
%         set([props.channelNamesNew{1:end-2,5}],{'YData'},num2cell(dataavgtoplot(1:end-1,:)*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingBFLY'))+1)/nTrials_good,2));%plot raw data
% end