function reset_GUI(handles)

%START/STOP
set(handles.pushbutton_start,'String','STOP')

%RAW controls
set(handles.slider_raw,'Visible','on')
set(handles.pushbutton_hold,'String','HOLD')

%amplitude SLIDER
set(handles.slider_raw,'Value',find(handles.input.slidervector==1))
setappdata(handles.slider_raw,'CurScalingRAW',get(handles.slider_raw,'Value'))
setappdata(handles.slider_raw,'CurScalingAVG',get(handles.slider_raw,'Value'))
setappdata(handles.slider_raw,'CurScalingBFLY',get(handles.slider_raw,'Value'))
% setappdata(handles.slider_raw,'CurScalingSINGLE',get(handles.slider_raw,'Value'))
% setappdata(handles.slider_raw,'CurScaling',get(handles.slider_raw,'Value'))
% set(handles.slider_avg,'Value',find(handles.input.slidervector==1))
% setappdata(handles.slider_avg,'CurScaling',get(handles.slider_avg,'Value'))
% set(handles.slider_bfly,'Value',find(handles.input.slidervector==1))
% setappdata(handles.slider_bfly,'CurScaling',get(handles.slider_bfly,'Value'))
% setappdata(handles.togglebutton_ampthresh,'threshold',0)

%DISPLAY
% set(handles.pushbutton_avg,'String','AVG')
set(handles.radiobutton_raw,'Value',1)
% set(handles.uibuttongroup_display,'Visible','on')
set(handles.radiobutton_avg,'Value',0)
set(handles.radiobutton_bfly,'Value',0)
set(handles.pushbutton_hold,'String','HOLD')

set(handles.uipanel_axesraw,'Visible','on')
set(handles.uipanel_axesavg,'Visible','off')
set(handles.uipanel_axesbfly,'Visible','off')
% set(handles.uipanel_singlepulse,'Visible','off')
% set(handles.slider_bfly,'Visible','off')

set(handles.uipanel_filters,'Visible','on')


% cla(handles.axes_raw)
cla(handles.axes_avg)
cla(handles.axes_bfly)
% cla(handles.axes_singlepulse)



%FILTERS
set(handles.edit_fmax,'String',num2str(handles.lowpass))
set(handles.edit_fstop,'String',num2str(handles.notch))
set(handles.togglebutton_pass,'Value',0)
set(handles.togglebutton_stop,'Value',0)

%TMS ARTIFACT rejection
set(handles.edit_tmin,'String',num2str(handles.artrej(1)))
set(handles.edit_tmax,'String',num2str(handles.artrej(2)))
set(handles.togglebutton_art,'Value',0)

%EOG ARTIFACT rejection
set(handles.edit_thresh,'String',num2str(handles.ampthresh))
set(handles.togglebutton_ampthresh,'Value',0)

%TRIALS text
set(handles.text_trials,'String','0/0')
setappdata(handles.pushbutton_common,'trialsgood',0)
setappdata(handles.pushbutton_common,'trials',0)




%RECORDING PARAMETERS
set(handles.text_sr,'String','')
set(handles.text_ampres,'String','')
set(handles.text_eegch,'String','')
set(handles.text_eogch,'String','')
set(handles.text_addch,'String','')
set(handles.panelacq,'Visible','off')

%AVG CONTROLS
% set(handles.slider_avg,'Visible','off')
set(handles.uipanel_axesavg,'Visible','off')
set(handles.uipanel_axesraw,'Visible','on')
set(handles.uipanel_axesbfly,'Visible','off')
set(handles.pushbutton_common,'String','COM ref')

% handles.zoom_obj = zoom(handles.figure1);
% handles.dcm_obj=datacursormode(handles.figure1);
% set(handles.dcm_obj,'DisplayStyle','window')
% set(handles.dcm_obj,'UpdateFcn',@myupdatefcn)


%%% canali bad/good da resettare












