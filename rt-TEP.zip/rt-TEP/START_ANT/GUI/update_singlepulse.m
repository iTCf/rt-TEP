% function update_singlepulse(handles,flagspm)
% 
% props=getappdata(handles.slider_raw,'props');
% input=getappdata(handles.slider_raw,'input');
% Hfilters=getappdata(handles.togglebutton_pass,'filters');
% 
% if flagspm
%     datatmp=getappdata(handles.pushbutton_common,'dataspm');
%     if isempty(datatmp)
%         datatmp=zeros(props.nEEG+1,length(input.timesavg));
%     end
% else
%     datatmp=zeros(props.nEEG+1,length(input.timesavg));
% end
% 
% % datatmp=datatmp*10;
% 
% %if TMS artifact rejection is on
% if get(handles.togglebutton_art,'Value')
%     datatmp(1:end,find(input.timesavg==0)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate:find(input.timesavg==0)+str2double(get(handles.edit_tmax,'String'))/1000*props.srate)=repmat(datatmp(1:end,find(input.timesavg==0)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate-1),[1,(str2double(get(handles.edit_tmax,'String'))-str2double(get(handles.edit_tmin,'String')))/1000*props.srate+1]);
% end
% 
% %check whether filtering is required
% switch get(handles.togglebutton_pass,'Value')
%     case 1
%         switch get(handles.togglebutton_stop,'Value')
%             case 1
%                 datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
%                 datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
%             case 0
%                 datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
%         end
%     case 0
%         switch get(handles.togglebutton_stop,'Value')
%             case 1
%                 datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
%         end
% end
% 
% set([props.channelNamesNew{1:end-1,6}],{'YData'},num2cell((datatmp-repmat(mean(datatmp,2),[1 size(datatmp,2)]))*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingSINGLE')))+input.delta(1:end-1,1:length(input.timesavg)),2));%plot raw data
% drawnow
