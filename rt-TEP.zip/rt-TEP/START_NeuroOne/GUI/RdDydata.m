function [dataavgtoplot,nTrials,nTrials_good]=RdDydata(handles,datarawtoplot,dataavgtoplot,ySeparation)

% [concheck,con]=check_connection(handles);
% ySeparation=300;
% if ~concheck
%     msgbox('Connection cannot be established!','Error','error');
%     cloh=close(h);
%     return
%     %uscire!!!
% end
set(handles.axes_raw,'XLim',[min(handles.input.timesraw) max(handles.input.timesraw)],'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom
set(handles.axes_raw,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'YTick',flipud(handles.input.delta(:,1)),{'YTickLabel'},{flipud(handles.props.channelNamesNew(:,1))},'FontSize',6);%catch size(input.delta)
% set(handles.axes_singlepulse,'XLim',handles.spm,'YLim',[-20  (2+handles.props.nEEG)*ySeparation+20]);%EEG and EOG channels plus trigger channel with ySeparation and 200 from top and from bottom


handles.zoom_obj = zoom(handles.figure1);
handles.dcm_obj=datacursormode(handles.figure1);
set(handles.dcm_obj,'DisplayStyle','window')
set(handles.dcm_obj,'UpdateFcn',{@mydata_cursor,handles})


% header_size = 24;
% tryheader=[];
% tic
% while isempty(tryheader) && toc<5
%     tryheader = pnet(con,'read',header_size,'byte','network','view','noblock'); % check for existing data in socket buffer
% end

udpr=dsp.UDPReceiver('LocalIPPort',50000,'RemoteIPAddress',handles.chord.ip,'ReceiveBufferSize',1048576,'MaximumMessageLength',65507);

tmp=[];
while isempty(tmp)
    tmp=step(udpr);
end
init_data=tmp;
tmp=[];
while isempty(tmp)
    tmp=step(udpr);
end
tmp2=tmp;
% handles.datahdr.points=swapbytes(typecast(tmp2(11:12),'uint16'));
% handles.datahdr.points=7;
tryheader=1;

handles.datahdr.points=swapbytes(typecast(tmp2(11:12),'uint16'))
mmatr=repmat([256^2 256 1]',[1,handles.datahdr.points*floor(0.1*handles.props.srate/handles.datahdr.points)]);
mmatr=repmat(mmatr,[handles.props.nEEG+handles.props.nEOG+1,1]);
% udps=dsp.UDPSender('RemoteIPAddress',handles.chord.ip,'RemoteIPPort',5050);
% dsent=uint8([128 0 0 0]);
% step(udps,dsent);


lastBlock=-1;
% nTrials=0;
% nTrials_good=0;
nTrials_good=getappdata(handles.pushbutton_common,'trialsgood');
nTrials=getappdata(handles.pushbutton_common,'trials');
start_trial=0;
while ~isempty(tryheader) && strcmp(get(handles.pushbutton_start,'String'),'STOP')
    cont1=0;%contatore per rate di aggiornamento dati raw
    cont2=0;%contatore per aggiornamento della media
    while cont1<handles.props.srate/handles.datahdr.points && strcmp(get(handles.pushbutton_start,'String'),'STOP') % plotta i dati raw ogni secondo
        %         hdr = ReadHeader(con);
        %         switch hdr.type
        %             case 1
        %                 props = ReadStartMessage(con, hdr);
        %                 lastBlock = -1;% Reset block counter to check overflows
        %             case 4       % 32Bit Data block
        %                 % Read data and markers from message
        mrkpos=[];
        tmp=[];
        %                 [datahdr, data, markers] = ReadDataMessage(con, hdr, props);
        datatmp=zeros(size(tmp2,1),floor(0.1*handles.props.srate/handles.datahdr.points));
        for hhh=1:floor(0.1*handles.props.srate/handles.datahdr.points)
            datatmptmp=step(udpr);
            while isempty(datatmptmp)
                datatmptmp=step(udpr);
            end
            
            datatmp(:,hhh)=datatmptmp;
            datahdr.block=swapbytes(typecast(uint8(datatmp(5:8,hhh)),'uint32'));
            cont1=cont1+1;
            
            % check tcpip buffer overflow
            if lastBlock~=-1 && lastBlock~=datahdr.block-1
                handles.overflow=handles.overflow+1;
                handles.overflow;
            end
            lastBlock=datahdr.block;
        end
        datatmp2=zeros((size(datatmp,1)-28)/handles.datahdr.points,handles.datahdr.points*size(datatmp,2));
        
        for hhh=1:size(datatmp,2)
            datatmp2(:,1+handles.datahdr.points*(hhh-1):handles.datahdr.points*hhh)=reshape(datatmp(29:end,hhh),[size(datatmp2,1) handles.datahdr.points]);
        end
        
        datatmp3=zeros(handles.props.nEEG+handles.props.nEOG+1,size(datatmp2,2));
        datatmp4=datatmp2.*mmatr;
        for hhh=1:handles.props.nEEG+handles.props.nEOG+1
            datatmp3(hhh,:)=sum(datatmp4(1+3*(hhh-1):hhh*3,:),1);
        end
        EEGData=double(datatmp3);
        %         EEGData = double(reshape(data, handles.props.channelCount, datahdr.points)); %Ritorna matrice (props.channelCount)X time samples
        
        %Check presence of stimulus
        %ci deve essere max 1 trigger su cui fare la media per pacchetto
        %                  markers=markers(1,1);
        %                  assignin('base','markers',markers)
        %=markers(1,1);
        %                  if ~cont2%SCSCSC
        %______________________
        %         if ~isempty(markers(1,1).description) && ~cont2
        %
        %             tmp=find(cellfun(@(x) strcmp(x,handles.markername),{markers.description}));
        %         end
        %         if datahdr.markerCount>0 && ~isempty(tmp) && ~cont2
        %             start_trial=1; %Devo iniziare a contare handles.displayparam.avg(2)/1000*handles.props.srate pacchetti alla dx dello stimolo
        %             mrkpos=markers(tmp).position+1;%Campione all'interno del pacchetto in cui c'� stato lo stimolo
        %         end
        %         %                  end
        %         if start_trial
        %             cont2=cont2+1;
        %         end
        %%
        %Process RAW data
        datarawtoplot(1:end-2,1:floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)=EEGData(handles.props.EEG,:)*handles.props.resolutionEEG;
        datarawtoplot(end,1:floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)=EEGData(end,:)*handles.props.resolutionEEG;
        if length(handles.EOGchannels)==1
            switch handles.EOGchannels
                case 0
                    datarawtoplot(end-1,1:floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)=0;
                otherwise
                    datarawtoplot(end-1,1:floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)=EEGData(handles.EOGchannels,:)*handles.props.resolutions(handles.EOGchannels);
            end
        else datarawtoplot(end-1,1:floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)=(EEGData(handles.EOGchannels(2),:)-EEGData(handles.EOGchannels(1),:))*handles.props.resolutions(handles.EOGchannels(1));
        end
        %                 datarawtoplot(end,1:handles.datahdr.points)=0;
        %         if mrkpos
        %             datarawtoplot(end,mrkpos)=100;
        %         end
        datarawtoplot=circshift(datarawtoplot,[0,-double(floor(0.1*handles.props.srate/handles.datahdr.points)*handles.datahdr.points)]);
        
        indx=find(datarawtoplot(end,:));
        if ~isempty(indx)
            for jj=1:length(indx)
                if indx(jj)<length(find(handles.input.timesavg<0))
                    datarawtoplot(end,indx(jj))=0;
                elseif indx(jj)<size(datarawtoplot,2)-length(find(handles.input.timesavg>0))
                    datarawtoplot(end,indx(jj))=0;
                    dataavgtmp=datarawtoplot(1:handles.props.nEEG+1,indx(jj)-length(find(handles.input.timesavg<0)):indx(jj)+length(find(handles.input.timesavg>0)));
                    dataavgtmp=dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-floor(0.01*handles.props.srate)),2),[1,size(dataavgtmp,2)]);%bl correction
                    nTrials=getappdata(handles.pushbutton_common,'trials')+1;
                    setappdata(handles.pushbutton_common,'trials',nTrials);
                    
                    if nTrials==1
                        dataavgtoplot=zeros(size(dataavgtmp));
                    else
                    dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
                    end
                    dataavgtoplot(1,1);
                    switch get(handles.togglebutton_ampthresh,'Value')
                        case 1
                            if max(abs(dataavgtmp(end,:)))<abs(str2double(get(handles.edit_thresh,'String')))
                                dataavgtoplot=dataavgtoplot+dataavgtmp;
                                datarawtoplot(end,indx(jj))=0;
                                nTrials_good= getappdata(handles.pushbutton_common,'trialsgood')+1;
                                setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                            end
                        case 0
                            dataavgtoplot=dataavgtoplot+dataavgtmp;
                            datarawtoplot(end,indx(jj))=0;
                            nTrials_good= getappdata(handles.pushbutton_common,'trialsgood')+1;
                            setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
                    end
                    %in questo caso dataavgtmp deve contenere solo 1 trial
%                     if get(handles.togglebutton_singlepulse,'Value')
%                         setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
%                         update_singlepulse(handles,1)
%                     end
                end
            end
            setappdata(handles.pushbutton_common,'datacom',dataavgtoplot)
%             %in questo caso dataavgtmp deve contenere solo 1 trial
%             if get(handles.togglebutton_singlepulse,'Value')
%                 setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
%                 update_singlepulse(handles,1)
%             end
            if getappdata(handles.pushbutton_common,'trialsgood')
                update_avg(handles)
            end
            set(handles.text_trials,'String',strcat(num2str(getappdata(handles.pushbutton_common,'trialsgood')),'/',num2str(getappdata(handles.pushbutton_common,'trials'))));
            
        end
        indx=[];
        %
        %         % a full trial has been recorded
        %         if start_trial==1 && cont2>length(find(handles.input.timesavg>0))/datahdr.points%cont2 && (lastBlock-cont2)>handles.displayparam.avg(2)/1000*handles.props.srate/datahdr.points % find(datarawtoplot(end,:),1,'last')-abs(handles.displayparam.avg(1))/1000*handles.props.srate>0 && find(datarawtoplot(end,:),1,'last')+handles.displayparam.avg(2)/1000*handles.props.srate<size(datarawtoplot,2)%
        %             nTrials=getappdata(handles.pushbutton_common,'trials')+1;
        %             setappdata(handles.pushbutton_common,'trials',nTrials);
        %             dataavgtmp=datarawtoplot(1:end-1,find(datarawtoplot(end,:),1,'last')-length(find(handles.input.timesavg<0)):find(datarawtoplot(end,:),1,'last')+length(find(handles.input.timesavg>0)));
        %             dataavgtmp=dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-floor(0.01*handles.props.srate)),2),[1,size(dataavgtmp,2)]);
        %
        %             dataavgtoplot=getappdata(handles.pushbutton_common,'datacom');%SCSCSCSCSC
        %
        %             %check whether EOG artifact rejection is on and the trial is good
        %             switch get(handles.togglebutton_ampthresh,'Value')
        %                 case 1
        %                     if max(abs(dataavgtmp(end,:)))<abs(str2double(get(handles.edit_thresh,'String')))
        %                         dataavgtoplot=dataavgtoplot+dataavgtmp;
        %                         %                                 dataavgtoplot=dataavgtoplot+(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)]));
        %                         nTrials_good=getappdata(handles.pushbutton_common,'trialsgood')+1;
        %                         setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
        %                     end
        %                 case 0
        %                     dataavgtoplot=dataavgtoplot+dataavgtmp;
        %                     %                             dataavgtoplot=dataavgtoplot+(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)]));
        %                     nTrials_good=getappdata(handles.pushbutton_common,'trialsgood')+1;
        %                     setappdata(handles.pushbutton_common,'trialsgood',nTrials_good);
        %             end
        %
        %             setappdata(handles.pushbutton_common,'datacom',dataavgtoplot)
        %             %                     setappdata(handles.pushbutton_common,'trialsgood',nTrials_good)
        %             %                     setappdata(handles.pushbutton_common,'trials',nTrials)
        %
        %             %check whether SINGLE PULSE mode is on
        %             if get(handles.togglebutton_singlepulse,'Value')
        %                 setappdata(handles.pushbutton_common,'dataspm',dataavgtmp)
        %                 %                         setappdata(handles.pushbutton_common,'dataspm',(dataavgtmp-repmat(mean(dataavgtmp(:,1:length(find(handles.input.timesavg<0))-0.01*handles.props.srate),2),[1,size(dataavgtoplot,2)])))
        %                 update_singlepulse(handles,1)
        %                 %                         set(handles.uipanel_singlepulse,'Visible','on')
        %                 %                         set(handles.slider_raw,'Value',getappdata(handles.slider_raw,'CurScalingSINGLE'))
        %                 %                         set(handles.uipanel_axesbfly,'Visible','off')
        %                 %                         set(handles.uipanel_axesavg,'Visible','off')
        %                 %                         set(handles.uipanel_axesraw,'Visible','off')
        %             end
        %
        %             %update AVG display
        %             if getappdata(handles.pushbutton_common,'trialsgood')
        %                 update_avg(handles)
        %             end
        %             set(handles.text_trials,'String',strcat(num2str(getappdata(handles.pushbutton_common,'trialsgood')),'/',num2str(getappdata(handles.pushbutton_common,'trials'))));
        %
        %             start_trial=0;
        %             cont2=0;
        %         end
        %         %         case 3       % Stop message
        %         %             disp('Stop');
        %         %             data = pnet(con, 'read', hdr.size - header_size);
        %         %             pnet('closeall');
        %         %             otherwise    % ignore all unknown types, but read the package from buffer
        %         %                 data = pnet(con, 'read', hdr.size - header_size);
        %         %                 %                 pnet('closeall');
        %     end
        %     if strcmp(get(handles.pushbutton_start,'String'),'STOP') % plotta i dati raw ogni secondo
        %         tryheader=[];
        %         while isempty(tryheader)
        %             tryheader = pnet(con, 'read', header_size, 'byte', 'network', 'view', 'noblock');
        %         end
        %     end
        % %________________________
        
    end
    
    setappdata(handles.pushbutton_common,'dataraw',datarawtoplot);
    
    update_raw(handles)
    
    cont1=0;%contatore per rate di aggiornamento dati raw
end
