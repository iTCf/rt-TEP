function closereq_startbamp(g,~)

button = questdlg({'You are about to close the BrainAmp START Interface. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
    cdir=fileparts(which('choose_amplifier.m'));
    pcdir=genpath(strcat(cdir,'\','START_BrainProducts'));
    rmpath(pcdir);
%     rmpath(strcat(cdir,'\START_BrainProducts'))
%     rmpath(strcat(cdir,'\START_BrainProducts\GUI'))
%     rmpath(strcat(cdir,'\START_BrainProducts\SDK'))
%     setappdata(g,'open',0)
% saveas(g,strcat(handles.savedir,'GUI_',datestr(now,'dd-mm-yyyy_HH:MM:SS'),'.fig'))
     delete(g)
% set(g,'Visible','off')
end

