% Read the message header
function hdr = ReadHeader(con)
    % con    tcpip connection object
    
    % define a struct for the header
    hdr = struct('uid',[],'size',[],'type',[]);

    % read id, size and type of the message
    % swapbytes is important for correct byte order of MATLAB variables
    % pnet behaves somehow strange with byte order option
    hdr.uid = pnet(con,'read', 16); %16 bytes(128-bit constant for unique identification),1x16 char
    hdr.size = swapbytes(pnet(con,'read', 1, 'uint32', 'network')); %1=dim--> un solo valore pari a 776,25636
    hdr.type = swapbytes(pnet(con,'read', 1, 'uint32', 'network')); 
end
