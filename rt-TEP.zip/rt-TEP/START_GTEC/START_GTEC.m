function varargout = START_GTEC(varargin)
% START_GTEC MATLAB code for START_GTEC.fig
%      START_GTEC, by itself, creates a new START_GTEC or raises the existing
%      singleton*.
%
%      H = START_GTEC returns the handle to a new START_GTEC or the handle to
%      the existing singleton*.
%
%      START_GTEC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in START_GTEC.M with the given input arguments.
%
%      START_GTEC('Property','Value',...) creates a new START_GTEC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before START_GTEC_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to START_GTEC_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help START_GTEC

% Last Modified by GUIDE v2.5 24-Aug-2021 13:13:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @START_GTEC_OpeningFcn, ...
                   'gui_OutputFcn',  @START_GTEC_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before START_GTEC is made visible.
function START_GTEC_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to START_GTEC (see VARARGIN)

% Choose default command line output for START_GTEC
handles.output = hObject;
% handles.hReceiveSocket=gUDPinit(8000);

setappdata(handles.edit_ip1,'ok',0)
setappdata(handles.edit_ip2,'ok',0)
setappdata(handles.edit_ip3,'ok',0)
setappdata(handles.edit_ip4,'ok',0)
setappdata(handles.edit_EOG,'ok',0)
% setappdata(handles.edit_mrk,'ok',0)
setappdata(handles.edit_rawinit,'ok',0)
setappdata(handles.edit_from,'ok',0)
setappdata(handles.edit_to,'ok',0)
setappdata(handles.pushbutton_savefull,'ok',0)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes START_GTEC wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = START_GTEC_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% % --- Executes on button press in pushbutton1.
% function pushbutton1_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% 
% % --- Executes on button press in pushbutton2.
% function pushbutton2_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton2 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton_startstart.
function pushbutton_startstart_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_startstart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

switch get(get(handles.uibuttongroup_init,'SelectedObject'), 'String')
    case 'LOAD full configuration'
        [FileName,PathName] = uigetfile('*.mat','Select full configuration file');
        if isempty(FileName) || unique(FileName==false)
            return
        end
        handles.fullconfig=load(strcat(PathName,FileName));
        handles.load='full';
        tmp=strfind(handles.fullconfig.input2GUI.ip,'.');
        set(handles.edit_ip1,'String',handles.fullconfig.input2GUI.ip(1:tmp(1)-1));
        setappdata(handles.edit_ip1,'ok',1)
        set(handles.edit_ip2,'String',handles.fullconfig.input2GUI.ip(tmp(1)+1:tmp(2)-1));
        setappdata(handles.edit_ip2,'ok',1)
        set(handles.edit_ip3,'String',handles.fullconfig.input2GUI.ip(tmp(2)+1:tmp(3)-1));
        setappdata(handles.edit_ip3,'ok',1)
        set(handles.edit_ip4,'String',handles.fullconfig.input2GUI.ip(tmp(3)+1:end));
        setappdata(handles.edit_ip4,'ok',1)
        clear tmp
%         set(handles.edit_mrk,'String',handles.fullconfig.input2GUI.mrk)
%         setappdata(handles.edit_mrk,'ok',1)
        set(handles.edit_EOG,'String',strcat('[',num2str(handles.fullconfig.input2GUI.EOG),']'))
        setappdata(handles.edit_EOG,'ok',1)
        set(handles.edit_rawinit,'String',num2str(handles.fullconfig.input2GUI.RAW))
        setappdata(handles.edit_rawinit,'ok',1)
        set(handles.edit_from,'String',num2str(handles.fullconfig.input2GUI.AVG(1)))
        setappdata(handles.edit_from,'ok',1)
        set(handles.edit_to,'String',num2str(handles.fullconfig.input2GUI.AVG(2)))
        setappdata(handles.edit_to,'ok',1)
        handles.chord.chlocs=handles.fullconfig.input2GUI.chord;
        handles.chord.ip=handles.fullconfig.input2GUI.ip;
        handles.displayparam.raw=handles.fullconfig.input2GUI.RAW;
        handles.displayparam.avg=handles.fullconfig.input2GUI.AVG;
        handles.EOGchannels=handles.fullconfig.input2GUI.EOG;
%         handles.markername=handles.fullconfig.input2GUI.mrk;
        setappdata(handles.pushbutton_savefull,'ok',1)
    case 'LOAD channel layout'
        [FileName,PathName] = uigetfile('*.mat','Select channel layout file');
        if isempty(FileName) || unique(FileName==false)
            return
        end
        handles.chord=load(strcat(PathName,FileName));
        if ~strcmp(cell2mat(fieldnames(handles.chord)),'chlocs')%if chlayout does not contain a chlocs field
            msgbox('Wrong file format!','Error');
        elseif ~isstruct(handles.chord.chlocs) %if chlocs is not a struct
            msgbox('Wrong file format!','Error');
        elseif size(handles.chord.chlocs,1)~=1%if chlocs has more than 1 rows
        elseif ~isequal(fieldnames(handles.chord.chlocs),{'labels';'Y';'X';'Z';'sph_theta';'sph_phi';'sph_radius';'theta';'radius';'sph_theta_besa';'sph_phi_besa';'type';'newlabels'})
            msgbox('Wrong file format!','Error');
        end
        handles.load='chord';
    case 'CREATE channel layout'
        handles.chordfig=chord;
        set(handles.chordfig,'CloseRequestFcn',@closereq_chord)
%         set(handles.chordfig,'Visible','off','CloseRequestFcn',@closereq_chord)
%         set(handles.chordfig,'Visible','on')
%         setappdata(handles.chordfig,'open',1)
        waitfor(handles.chordfig,'Visible','off')
        delete(handles.chordfig)
        set(handles.radiobutton_load,'Value',1)
        h = msgbox('To start an experimental session, press START','Success');
end

guidata(hObject, handles);


function edit_mrk_Callback(hObject, eventdata, handles)
% hObject    handle to edit_mrk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_mrk as text
%        str2double(get(hObject,'String')) returns contents of edit_mrk as a double

setappdata(handles.edit_mrk,'ok',1)

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_mrk_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_mrk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ip1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ip1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ip1 as text
%        str2double(get(hObject,'String')) returns contents of edit_ip1 as a double
tmp=str2num(get(handles.edit_ip1,'String'));
if ~isempty(tmp) && tmp>=1 && tmp<=223
    setappdata(handles.edit_ip1,'ok',1)
else
    set(handles.edit_ip1,'String','000')
    msgbox('Wrong IP address! Expected value between 1 and 223!','Error');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_ip1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ip1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ip2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ip2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ip2 as text
%        str2double(get(hObject,'String')) returns contents of edit_ip2 as a double
tmp=str2num(get(handles.edit_ip2,'String'));
if ~isempty(tmp) && tmp>=1 && tmp<=255
    setappdata(handles.edit_ip2,'ok',1)
else
    set(handles.edit_ip2,'String','000')
    msgbox('Wrong IP address! Expected value between 0 and 255!','Error');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_ip2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ip2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ip3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ip3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ip3 as text
%        str2double(get(hObject,'String')) returns contents of edit_ip3 as a double
tmp=str2num(get(handles.edit_ip3,'String'));
if ~isempty(tmp) && tmp>=1 && tmp<=255
    setappdata(handles.edit_ip3,'ok',1)
else
    set(handles.edit_ip3,'String','000')
    msgbox('Wrong IP address! Expected value between 0 and 255!','Error');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_ip3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ip3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_EOG_Callback(hObject, eventdata, handles)
% hObject    handle to edit_EOG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_EOG as text
%        str2double(get(hObject,'String')) returns contents of edit_EOG as a double

tmp=str2num(get(handles.edit_EOG,'String'));
if ~isempty(tmp) && (length(tmp)==1 || length(tmp)==2)
    setappdata(handles.edit_EOG,'ok',1)
else 
    msgbox('Specify 1 or 2 channel numbers for EOG!','Error','error');
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_EOG_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_EOG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_rawinit_Callback(hObject, eventdata, handles)
% hObject    handle to edit_rawinit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_rawinit as text
%        str2double(get(hObject,'String')) returns contents of edit_rawinit as a double
tmp=str2num(get(handles.edit_rawinit,'String'));
if ~isempty(tmp) && length(tmp)==1
    setappdata(handles.edit_rawinit,'ok',1)
else 
    msgbox('Specify one time window length in s!','Error','error');
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_rawinit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_rawinit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% 
% function edit7_Callback(hObject, eventdata, handles)
% % hObject    handle to edit7 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: get(hObject,'String') returns contents of edit7 as text
% %        str2double(get(hObject,'String')) returns contents of edit7 as a double
% 
% 
% % --- Executes during object creation, after setting all properties.
% function edit7_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to edit7 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end



function edit_from_Callback(hObject, eventdata, handles)
% hObject    handle to edit_from (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_from as text
%        str2double(get(hObject,'String')) returns contents of edit_from as a double
tmp=str2num(get(handles.edit_from,'String'));
if ~isempty(tmp) && length(tmp)==1
    if tmp<0
    setappdata(handles.edit_from,'ok',1)
    else 
        msgbox('Starting point must be negative!','Error','error');
    end
else 
    msgbox('Specify time window starting point in ms!','Error','error');
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_from_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_from (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_check.
function pushbutton_check_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if isfield(handles,'load') && (getappdata(handles.edit_ip1,'ok') && getappdata(handles.edit_ip2,'ok') && getappdata(handles.edit_ip3,'ok') && getappdata(handles.edit_ip4,'ok'))
%     handles.chord.ip=strcat(get(handles.edit_ip1,'String'),'.',get(handles.edit_ip2,'String'),'.',get(handles.edit_ip3,'String'),'.',get(handles.edit_ip4,'String'));
%     [outval]=GUI_initialization_START(handles);
% else outval=0;
% end
% if outval
%     msgbox('Connection successfull!','Success');
% else
%     if ~isfield(handles,'load')
%     msgbox({'Check connection failed!','Missing channel layout!'},'Error','error');
%     end
%     if ~(getappdata(handles.edit_ip1,'ok') && getappdata(handles.edit_ip2,'ok') && getappdata(handles.edit_ip3,'ok') && getappdata(handles.edit_ip4,'ok'))
%     msgbox({'Check connection failed!','Incorrect IP address!'},'Error','error');
%     end
% end
% 

guidata(hObject, handles);


% --- Executes on button press in pushbutton_startGUI.
function pushbutton_startGUI_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_startGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tmp=0;
if getappdata(handles.edit_sr,'ok') && getappdata(handles.edit_ip1,'ok') && getappdata(handles.edit_ip2,'ok') && getappdata(handles.edit_ip3,'ok') && getappdata(handles.edit_ip4,'ok') && getappdata(handles.edit_EOG,'ok') && getappdata(handles.edit_rawinit,'ok') && getappdata(handles.edit_from,'ok') && getappdata(handles.edit_to,'ok') % && getappdata(handles.edit_mrk,'ok') 
    input2GUI.ip=strcat(get(handles.edit_ip1,'String'),'.',get(handles.edit_ip2,'String'),'.',get(handles.edit_ip3,'String'),'.',get(handles.edit_ip4,'String'));
%     input2GUI.mrk=get(handles.edit_mrk,'String');
    input2GUI.EOG=str2num(get(handles.edit_EOG,'String'));
    input2GUI.RAW=str2num(get(handles.edit_rawinit,'String'));
    input2GUI.AVG=cat(2,str2num(get(handles.edit_from,'String')),str2num(get(handles.edit_to,'String')));
    input2GUI.srate=str2num(get(handles.edit_sr,'String'));
    tmp=1;
    else
    msgbox('Open GUI: failed because configuration parameters have not been fully provided','Error');
end
if isfield(handles,'chord')
    if isfield(handles.chord,'chlocs')
        input2GUI.chord=handles.chord.chlocs;
    else tmp=0;
        msgbox('Open GUI: failed because channel layout is missing','Error');
    end
end

if tmp
%     pushbutton_check_Callback(hObject, eventdata, handles)
% input2GUI.socket=handles.hReceiveSocket;
% handles.hReceiveSocket
    handles.gtecfig=GTEC_TMSEEG_interface(input2GUI);
    set(handles.gtecfig,'CloseRequestFcn',@closereq_gtec)    
    %close START
end
guidata(hObject, handles);

% --- Executes on button press in pushbutton_savefull.
function pushbutton_savefull_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_savefull (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tmp=0;
if getappdata(handles.edit_ip1,'ok') && getappdata(handles.edit_ip2,'ok') && getappdata(handles.edit_ip3,'ok') && getappdata(handles.edit_ip4,'ok') && getappdata(handles.edit_EOG,'ok') && getappdata(handles.edit_rawinit,'ok') && getappdata(handles.edit_from,'ok') && getappdata(handles.edit_to,'ok') % getappdata(handles.edit_mrk,'ok') && 
    input2GUI.ip=strcat(get(handles.edit_ip1,'String'),'.',get(handles.edit_ip2,'String'),'.',get(handles.edit_ip3,'String'),'.',get(handles.edit_ip4,'String'));
%     input2GUI.mrk=get(handles.edit_mrk,'String');
    input2GUI.EOG=str2num(get(handles.edit_EOG,'String'));
    input2GUI.RAW=str2num(get(handles.edit_rawinit,'String'));
    input2GUI.AVG=cat(2,str2num(get(handles.edit_from,'String')),str2num(get(handles.edit_to,'String')));
    tmp=1;
    else
    msgbox('Saving failed because configuration parameters have not been fully provided','Error');
end
if isfield(handles,'chord')
    if isfield(handles.chord,'chlocs')
        input2GUI.chord=handles.chord.chlocs;
    else tmp=0;
        msgbox('Saving failed because channel layout is missing','Error');
    end
end
if tmp==1
    [FileName,PathName] = uiputfile('*.mat','Select a folder to save this configuration...','_fullconfig.mat');
    if ~isnumeric(FileName) && ~isnumeric(PathName)
        save(strcat(PathName,FileName),'input2GUI')%%%%%%%%%%%%%
    end
end
guidata(hObject, handles);


function edit_ip4_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ip4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ip4 as text
%        str2double(get(hObject,'String')) returns contents of edit_ip4 as a double
tmp=str2num(get(handles.edit_ip4,'String'));
if ~isempty(tmp) && tmp>=1 && tmp<=255
    setappdata(handles.edit_ip4,'ok',1)
else
    set(handles.edit_ip4,'String','000')
    msgbox('Wrong IP address! Expected value between 0 and 255!','Error');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_ip4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ip4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_to_Callback(hObject, eventdata, handles)
% hObject    handle to edit_to (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_to as text
%        str2double(get(hObject,'String')) returns contents of edit_to as a double
tmp=str2num(get(handles.edit_to,'String'));
if ~isempty(tmp) && length(tmp)==1
    if tmp>0
        setappdata(handles.edit_to,'ok',1)
    else
        msgbox('Starting point must be positive!','Error','error');
    end
else
    msgbox('Specify time window ending point in ms!','Error','error');
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_to_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_to (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_sr_Callback(hObject, eventdata, handles)
% hObject    handle to edit_sr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_sr as text
%        str2double(get(hObject,'String')) returns contents of edit_sr as a double


% --- Executes during object creation, after setting all properties.
function edit_sr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_sr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
