function closereq_gtec(g,~)

button = questdlg({'You are about to close the GTEC GUI Interface. Are you sure you want to continue?'},'Closing...','YES','NO','NO') ;
if strcmp(button,'YES')
%     setappdata(g,'open',0)
% saveas(g,strcat(handles.savedir,'GUI_',datestr(now,'dd-mm-yyyy_HH:MM:SS'),'.fig'))
     delete(g)
% set(g,'Visible','off')
end

