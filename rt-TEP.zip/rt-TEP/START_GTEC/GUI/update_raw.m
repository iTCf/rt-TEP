function update_raw(handles)

props=getappdata(handles.slider_raw,'props');
input=getappdata(handles.slider_raw,'input');
Hfilters=getappdata(handles.togglebutton_pass,'filters');

%check whether HOLD SCREEN is required
% try
    if strcmp(get(handles.pushbutton_hold,'String'),'HOLD')
        datatmp=getappdata(handles.pushbutton_common,'dataraw');
    else
        datatmp=getappdata(handles.pushbutton_hold,'datahold');
    end
% catch
if isempty(datatmp)
    datatmp=zeros(props.nEEG+2,length(input.timesraw));
end

%check whether TMS artifact rejection is required
if get(handles.togglebutton_art,'Value')
    tmp=find(datatmp(end,:));
    for jj=1:length(tmp)
        if tmp(jj)<=abs(str2double(get(handles.edit_tmin,'String'))/1000*props.srate)
             datatmp(1:end-1,1:tmp(jj)+ceil(str2double(get(handles.edit_tmax,'String'))/1000*props.srate))=0;
        elseif tmp(jj)+ceil(str2double(get(handles.edit_tmax,'String'))/1000*props.srate)>length(input.timesraw) 
            datatmp(1:end-1,tmp(jj)+ceil(str2double(get(handles.edit_tmin,'String'))/1000*props.srate):end)=0;%repmat(datatmp(1:end-1,tmp(jj)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate-1),[1,(length(input.timesraw)-(tmp(jj)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate)+1)]);
        else datatmp(1:end-1,tmp(jj)+floor(str2double(get(handles.edit_tmin,'String'))/1000*props.srate):tmp(jj)+ceil(str2double(get(handles.edit_tmax,'String'))/1000*props.srate))=repmat(datatmp(1:end-1,tmp(jj)+floor(str2double(get(handles.edit_tmin,'String'))/1000*props.srate)-1),[1,length(tmp(jj)+floor(str2double(get(handles.edit_tmin,'String'))/1000*props.srate):tmp(jj)+ceil(str2double(get(handles.edit_tmax,'String'))/1000*props.srate))]);
            %        datatmp(1:end-1,tmp(jj)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate:tmp(jj)+str2double(get(handles.edit_tmax,'String'))/1000*props.srate)=repmat(datatmp(1:end-1,tmp(jj)+str2double(get(handles.edit_tmin,'String'))/1000*props.srate-1),[1,(str2double(get(handles.edit_tmax,'String'))-str2double(get(handles.edit_tmin,'String')))/1000*props.srate+1]);
            
        end
    end
end

%check whether filtering is required
switch get(handles.togglebutton_pass,'Value')
    case 1
        switch get(handles.togglebutton_stop,'Value')
            case 1
                datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
                datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
            case 0
                datatmp=filtfilt(Hfilters.Bl,Hfilters.Al,datatmp')';
        end
    case 0
        switch get(handles.togglebutton_stop,'Value')
            case 1
                datatmp=filtfilt(Hfilters.Bn,Hfilters.An,datatmp')';
        end
end
tmp=(datatmp-repmat(mean(datatmp,2),[1 size(datatmp,2)]))*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingRAW')));
% size(tmp)
% if size(tmp,2)~=25000
%     save silvia.mat
% end
set([props.channelNamesNew{:,2}],{'YData'},num2cell((datatmp-repmat(mean(datatmp,2),[1 size(datatmp,2)]))*input.slidervector(round(getappdata(handles.slider_raw,'CurScalingRAW')))+input.delta,2));%plot raw data
drawnow


