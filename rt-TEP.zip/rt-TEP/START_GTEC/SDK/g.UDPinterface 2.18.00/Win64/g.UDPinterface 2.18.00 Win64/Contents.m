% g.UDPinterface
% Version 2.18.00 (R2018 Win64) g.tec medical engineering GmbH